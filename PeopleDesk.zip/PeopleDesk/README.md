# PeopleDesk — UI Refresh v2

A refreshed React 19 + Vite employee management UI. The existing module components, mock data, and localStorage-backed interactions are retained.

## Run locally

1. Extract this ZIP into a **new folder** (do not merge it into the old `t36` folder).
2. Open the extracted `PeopleDesk` folder in VS Code.
3. In the terminal, confirm you are in the folder containing `package.json`.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the **new URL printed by Vite**. If you already have an older Vite server running, stop it with `Ctrl+C` in its terminal first. Avoid reusing an old browser tab/server URL.
6. If the old page still appears, hard-refresh with `Ctrl+Shift+R`.

## What changed in v2

- Added a page-specific wrapper for Dashboard, Employees, Attendance, Leave, Reports, and Settings so the redesigned styles apply to the actual active module.
- Reworked the app canvas, navigation rail, spacing, cards, typography, tables, inputs, modal surfaces, focus states, and responsive behavior.
- Replaced the old four-column dashboard metric presentation with modern white KPI cards and responsive grid behavior.
- Added tablet/mobile navigation and table overflow handling.
- Refined dark-mode styling while retaining the existing app toggle.

## Notes

- This project currently uses mock data and browser `localStorage`; it is not connected to a backend database.
- Existing localStorage data remains in the browser. To reset the sample state if needed, open DevTools → Application → Local Storage and remove keys beginning with `peopledesk_`.
- Run `npm run build` locally to validate the production build after dependency installation.
