import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import LeaveModule from "./components/LeaveModule";
import DashboardOverview from "./components/DashboardOverview";
import EmployeeModule from "./components/EmployeeModule";
import AttendanceModule from "./components/AttendanceModule";
import ReportsModule from "./components/ReportsModule";
import SettingsView from "./components/Settingsview";
import { initialEmployees, initialLeaveData } from "./mockData";
import { ADMIN } from "./config";
import {
  todayISO, setDateFormatPref, setCompanyNamePref,
  reconcileAttendance, reconcileLeaves, normalizeLeave, formatDateRange, hasTime,
} from "./utils/helpers";
import "./App.css";

const DEFAULT_SETTINGS = {
  company: { name: "Employee Management System", defaultDepartment: "Engineering", dateFormat: "DD MMM YYYY" },
  notifications: {
    "Attendance reminders": true,
    "Leave request updates": true,
    "Company announcements": true,
    "Employee directory updates": false,
  },
  profile: { employeeId: "EMP-001", phone: "+1 (555) 123-4567", employmentType: "Full Time" },
};

const SECTION_LABELS = { dashboard: "Dashboard", employee: "Employees", attendance: "Attendance", leave: "Leave", reports: "Reports", settings: "Settings" };

const TAB_IDS = Object.keys(SECTION_LABELS);
const tabFromHash = () => {
  const h = window.location.hash.replace(/^#\/?/, "");
  return TAB_IDS.includes(h) ? h : null;
};

const ACCENTS = {
  blue: ["#1e4fd8", "#183fb0"], indigo: ["#4f46e5", "#4338ca"], violet: ["#7c3aed", "#6d28d9"],
  rose: ["#e11d48", "#be123c"], orange: ["#ea580c", "#c2410c"], emerald: ["#059669", "#047857"], cyan: ["#0891b2", "#0e7490"],
};

const load = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

export default function App() {
  const [activeTab, setActiveTabState] = useState(() => tabFromHash() || localStorage.getItem("peopledesk_active_tab") || "dashboard");
  /* Changes every time a page is opened, so the page is rebuilt from scratch (a true page refresh) */
  const [pageKey, setPageKey] = useState(0);
  const [accent, setAccent] = useState(() => localStorage.getItem("peopledesk_accent") || "default");
  const mainRef = useRef(null);

  const setActiveTab = useCallback((tab) => {
    if (!TAB_IDS.includes(tab)) return;
    setActiveTabState(tab);
    setSettingsSubTab("profile");
    setPageKey((k) => k + 1);
    if (window.location.hash !== `#/${tab}`) window.history.pushState(null, "", `#/${tab}`);
    window.scrollTo(0, 0);
  }, []);

  /* Browser back / forward also opens a fresh page */
  useEffect(() => {
    const onHash = () => {
      const t = tabFromHash();
      if (t) { setActiveTabState(t); setSettingsSubTab("profile"); setPageKey((k) => k + 1); }
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  /* Alt + 1..6 jumps between pages */
  useEffect(() => {
    const onKey = (e) => {
      if (!e.altKey || e.ctrlKey || e.metaKey) return;
      const i = Number(e.key) - 1;
      if (i >= 0 && i < TAB_IDS.length) { e.preventDefault(); setActiveTab(TAB_IDS[i]); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [setActiveTab]);
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem("peopledesk_logged_in") !== "false");
  /* Appearance: light, dark, system or one of the colour themes (older "dark mode" setting is migrated) */
  const [theme, setTheme] = useState(() =>
    localStorage.getItem("peopledesk_theme") ||
    (localStorage.getItem("peopledesk_dark_mode") === "true" ? "dark" : "light")
  );
  const [density, setDensity] = useState(() => localStorage.getItem("peopledesk_density") || "comfortable");
  const [settingsSubTab, setSettingsSubTab] = useState("profile");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => localStorage.getItem("peopledesk_sidebar_collapsed") === "true");

  const [settings, setSettings] = useState(() => {
    const saved = load("peopledesk_settings", {});
    return {
      company: {
        ...DEFAULT_SETTINGS.company,
        ...saved.company,
        /* the old built-in title is replaced by the new default; any custom name is kept */
        name: !saved.company?.name || saved.company.name === "PeopleDesk" ? DEFAULT_SETTINGS.company.name : saved.company.name,
      },
      notifications: { ...DEFAULT_SETTINGS.notifications, ...saved.notifications },
      profile: { ...DEFAULT_SETTINGS.profile, ...saved.profile },
    };
  });

  /* The administrator's e-mail is fixed; older saved data is brought in line once. */
  const [employees, setEmployees] = useState(() =>
    load("peopledesk_employees", initialEmployees).map((e) =>
      e.id === "EMP-001" && e.email === "alex.m@peopledesk.com" ? { ...e, email: ADMIN.email } : e
    )
  );
  const [leaveData, setLeaveData] = useState(() => load("peopledesk_leaves", initialLeaveData));
  const [attendanceData, setAttendanceData] = useState(() =>
    reconcileAttendance(load("peopledesk_attendance_v2", []), employees, leaveData)
  );

  const [auditLog, setAuditLog] = useState(() => load("peopledesk_audit", []));

  /* Company preferences are applied before anything renders, so every page picks them up. */
  setDateFormatPref(settings.company.dateFormat);
  setCompanyNamePref(settings.company.name);

  /* ---------- Persistence ---------- */
  useEffect(() => { localStorage.setItem("peopledesk_active_tab", activeTab); }, [activeTab]);
  useEffect(() => {
    localStorage.setItem("peopledesk_accent", accent);
    const root = document.documentElement;
    const pair = ACCENTS[accent];
    ["--primary", "--primary-hover", "--action", "--action-hover"].forEach((v) => root.style.removeProperty(v));
    if (pair) {
      root.style.setProperty("--primary", pair[0]);
      root.style.setProperty("--primary-hover", pair[1]);
      root.style.setProperty("--action", pair[0]);
      root.style.setProperty("--action-hover", pair[1]);
    }
  }, [accent, theme]);
  useEffect(() => { localStorage.setItem("peopledesk_logged_in", String(isLoggedIn)); }, [isLoggedIn]);
  useEffect(() => {
    localStorage.setItem("peopledesk_theme", theme);
    const media = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
    const apply = () => {
      const resolved = theme === "system" ? (media && media.matches ? "dark" : "light") : theme;
      document.documentElement.setAttribute("data-theme", resolved);
    };
    apply();
    if (theme !== "system" || !media) return undefined;
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [theme]);
  useEffect(() => {
    localStorage.setItem("peopledesk_density", density);
    document.documentElement.setAttribute("data-density", density);
  }, [density]);
  useEffect(() => { localStorage.setItem("peopledesk_audit", JSON.stringify(auditLog)); }, [auditLog]);
  useEffect(() => { localStorage.setItem("peopledesk_sidebar_collapsed", String(sidebarCollapsed)); }, [sidebarCollapsed]);
  useEffect(() => { localStorage.setItem("peopledesk_settings", JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem("peopledesk_employees", JSON.stringify(employees)); }, [employees]);
  useEffect(() => { localStorage.setItem("peopledesk_leaves", JSON.stringify(leaveData)); }, [leaveData]);
  useEffect(() => { localStorage.setItem("peopledesk_attendance_v2", JSON.stringify(attendanceData)); }, [attendanceData]);
  useEffect(() => { document.title = `${settings.company.name} · HR Management`; }, [settings.company.name]);

  /* ---------- Keep everything in step with the employee list ---------- */
  useEffect(() => {
    setAttendanceData((prev) => {
      const next = reconcileAttendance(prev, employees, leaveData);
      return JSON.stringify(next) === JSON.stringify(prev) ? prev : next;
    });
    setLeaveData((prev) => {
      const next = reconcileLeaves(prev, employees);
      return next.length === prev.length ? prev : next;
    });
  }, [employees, leaveData]);

  /* ---------- Activity log: records what changed, by comparing before / after ---------- */
  const pushLog = useCallback((items) => {
    if (!items.length) return;
    const stamp = Date.now();
    const rows = items.map((it, i) => ({
      id: `${stamp}-${i}-${Math.random().toString(36).slice(2, 7)}`,
      time: new Date(stamp).toISOString(),
      actor: ADMIN.name,
      tone: "blue",
      ...it,
    }));
    setAuditLog((prev) => [...rows.reverse(), ...prev].slice(0, 300));
  }, []);

  const prevEmployees = useRef(employees);
  const prevLeaves = useRef(leaveData);
  const prevAttendance = useRef(attendanceData);

  useEffect(() => {
    const prev = prevEmployees.current;
    prevEmployees.current = employees;
    if (prev === employees) return;
    const before = new Map(prev.map((e) => [e.id, e]));
    const after = new Map(employees.map((e) => [e.id, e]));
    const items = [];
    employees.forEach((e) => {
      const p = before.get(e.id);
      if (!p) items.push({ action: "Employee added", tone: "green", detail: `${e.name} (${e.id}) · ${e.department}` });
      else if (JSON.stringify(p) !== JSON.stringify(e)) {
        const FIELDS = [["name", "Name"], ["email", "Email"], ["department", "Department"], ["designation", "Designation"], ["joined", "Joining date"], ["status", "Status"]];
        const changed = FIELDS.filter(([k]) => (p[k] || "") !== (e[k] || "")).map(([, label]) => label);
        items.push({ action: "Employee updated", tone: "blue", detail: `${e.name} (${e.id})${changed.length ? ` · changed: ${changed.join(", ")}` : ""}` });
      }
    });
    prev.forEach((p) => { if (!after.has(p.id)) items.push({ action: "Employee removed", tone: "red", detail: `${p.name} (${p.id})` }); });
    pushLog(items.length > 6 ? [{ action: "Directory replaced", tone: "amber", detail: `${items.length} employee records changed at once (restore or reset)` }] : items);
  }, [employees, pushLog]);

  useEffect(() => {
    const prev = prevLeaves.current;
    prevLeaves.current = leaveData;
    if (prev === leaveData) return;
    const before = new Map(prev.map((l) => [l.leaveId, l]));
    const items = [];
    leaveData.forEach((l) => {
      const n = normalizeLeave(l, employees);
      const p = before.get(l.leaveId);
      if (!p) items.push({ action: "Leave requested", tone: "amber", detail: `${n.empName} · ${n.leaveType} · ${formatDateRange(n.startDate, n.endDate)}` });
      else if ((p.status || "Pending") !== (l.status || "Pending")) {
        items.push({ action: `Leave ${String(l.status).toLowerCase()}`, tone: l.status === "Approved" ? "green" : l.status === "Rejected" ? "red" : "amber", detail: `${n.empName} · ${n.leaveType}` });
      }
    });
    pushLog(items.length > 6 ? [{ action: "Leave data replaced", tone: "amber", detail: `${items.length} leave records changed at once` }] : items);
  }, [leaveData, employees, pushLog]);

  useEffect(() => {
    const prev = prevAttendance.current;
    prevAttendance.current = attendanceData;
    if (prev === attendanceData) return;
    const before = new Map(prev.map((a) => [`${a.empId || a.id}|${a.date}`, a]));
    const items = [];
    attendanceData.forEach((a) => {
      const p = before.get(`${a.empId || a.id}|${a.date}`);
      if (!p) return;
      const name = a.empName || a.name;
      if (hasTime(a.checkIn) && a.checkIn !== p.checkIn) items.push({ action: "Check-in", tone: "green", detail: `${name} at ${a.checkIn}` });
      else if (hasTime(a.checkOut) && a.checkOut !== p.checkOut) items.push({ action: "Check-out", tone: "blue", detail: `${name} at ${a.checkOut}` });
      else if (a.status === "Absent" && hasTime(p.checkIn) && !hasTime(a.checkIn)) items.push({ action: "Marked absent", tone: "red", detail: name });
      else if (a.status === "On Leave" && p.status !== "On Leave") items.push({ action: "Marked on leave", tone: "amber", detail: name });
    });
    pushLog(items.length > 6 ? [{ action: "Attendance replaced", tone: "amber", detail: `${items.length} attendance records changed at once` }] : items);
  }, [attendanceData, pushLog]);

  /* The signed-in profile is read from the employee directory (single source of truth). */
  const profile = useMemo(() => {
    const p = settings.profile;
    const emp = employees.find((e) => e.id === p.employeeId);
    return {
      employeeId: p.employeeId,
      phone: p.phone,
      employmentType: p.employmentType,
      fullName: emp ? emp.name : "Administrator",
      email: emp ? emp.email : "",
      jobRole: emp ? emp.designation || "" : "",
      department: emp ? emp.department : settings.company.defaultDepartment,
      joiningDate: emp ? emp.joined || "" : "",
      linked: !!emp,
    };
  }, [settings.profile, settings.company.defaultDepartment, employees]);

  /* The signed-in administrator is fixed (Settings > Account & appearance) */
  const currentUser = isLoggedIn ? ADMIN.name : "Guest";

  /* Settings -> whole project */
  const saveProfile = (form) => {
    setEmployees((prev) =>
      prev.map((e) =>
        e.id === form.employeeId
          ? { ...e, name: form.fullName.trim(), email: form.email.trim(), designation: form.jobRole.trim(), department: form.department, joined: form.joiningDate }
          : e
      )
    );
    setSettings((s) => ({ ...s, profile: { employeeId: form.employeeId, phone: form.phone, employmentType: form.employmentType } }));
  };
  const saveCompany = (company) => setSettings((s) => ({ ...s, company }));
  const saveNotifications = (notifications) => setSettings((s) => ({ ...s, notifications }));

  /* ---------- Dashboard numbers (today) ---------- */
  const today = todayISO();
  const todayRows = attendanceData.filter((a) => a.date === today);
  const totalEmployees = employees.length;
  const activeCount = employees.filter((e) => e.status === "Active").length;
  const countStatus = (s) => todayRows.filter((a) => a.status === s).length;
  const presentToday = countStatus("Present") + countStatus("Late") + countStatus("Half-Day");
  const onLeaveToday = countStatus("On Leave");
  const absentToday = countStatus("Absent");
  const attendancePercentage = totalEmployees > 0 ? `${((presentToday / totalEmployees) * 100).toFixed(1)}%` : "0.0%";
  const pendingLeaves = leaveData.filter((l) => (l.status || "Pending") === "Pending").length;

  const deptMap = employees.reduce((acc, emp) => {
    acc[emp.department] = (acc[emp.department] || 0) + 1;
    return acc;
  }, {});
  const departmentStats = Object.entries(deptMap)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  /* ---------- Notification bell (follows the switches in Settings > Notifications) ---------- */
  const alerts = useMemo(() => {
    const n = settings.notifications;
    const list = [];
    if (n["Leave request updates"] && pendingLeaves > 0) {
      list.push({ id: "pending", tone: "amber", tab: "leave", title: `${pendingLeaves} leave ${pendingLeaves === 1 ? "request needs" : "requests need"} approval`, detail: "Open Leave to review" });
    }
    if (n["Attendance reminders"] && absentToday > 0) {
      list.push({ id: "absent", tone: "red", tab: "attendance", title: `${absentToday} ${absentToday === 1 ? "employee has" : "employees have"} not checked in`, detail: "Marked absent so far today" });
    }
    if (n["Company announcements"]) {
      const t = new Date();
      employees.forEach((e) => {
        const d = e.joined ? new Date(`${e.joined}T00:00:00`) : null;
        if (d && d.getMonth() === t.getMonth() && d.getDate() === t.getDate() && d.getFullYear() < t.getFullYear()) {
          list.push({ id: `anniv-${e.id}`, tone: "green", tab: "employee", title: `${e.name} celebrates ${t.getFullYear() - d.getFullYear()} year(s) today`, detail: "Work anniversary" });
        }
      });
      leaveData.map((l) => normalizeLeave(l, employees))
        .filter((l) => l.status === "Approved" && l.startDate <= today && l.endDate >= today)
        .slice(0, 3)
        .forEach((l) => list.push({ id: `out-${l.leaveId}`, tone: "blue", tab: "leave", title: `${l.empName} is on leave today`, detail: formatDateRange(l.startDate, l.endDate) }));
    }
    if (n["Employee directory updates"]) {
      /* Changes made to the directory in the last 7 days (added, edited, removed) with full details */
      const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      const DIRECTORY_ACTIONS = ["Employee added", "Employee updated", "Employee removed", "Directory replaced"];
      auditLog
        .filter((l) => DIRECTORY_ACTIONS.includes(l.action) && new Date(l.time).getTime() >= weekAgo)
        .slice(0, 5)
        .forEach((l) => list.push({
          id: `dir-${l.id}`,
          tone: l.tone || "blue",
          tab: "employee",
          title: l.action,
          detail: `${l.detail} · ${new Date(l.time).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}`,
        }));
      const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
      employees.filter((e) => e.joined && new Date(`${e.joined}T00:00:00`) >= cutoff).slice(0, 3)
        .forEach((e) => list.push({ id: `new-${e.id}`, tone: "blue", tab: "employee", title: `${e.name} joined recently`, detail: `${e.designation || "Employee"} · ${e.department} · ${e.email}` }));
    }
    return list;
  }, [settings.notifications, pendingLeaves, absentToday, employees, leaveData, today, auditLog]);

  /* ---------- Backup / restore (Settings > Data & backup) ---------- */
  const exportBackup = () => {
    const payload = { app: "PeopleDesk", version: 1, exportedAt: new Date().toISOString(), settings, employees, leaveData, attendanceData };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `peopledesk_backup_${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 500);
  };
  const importBackup = (text) => {
    const data = JSON.parse(text);
    if (data.app !== "PeopleDesk" || !Array.isArray(data.employees)) throw new Error("This is not a PeopleDesk backup file.");
    setEmployees(data.employees);
    setLeaveData(Array.isArray(data.leaveData) ? data.leaveData : []);
    setAttendanceData(Array.isArray(data.attendanceData) ? data.attendanceData : []);
    if (data.settings) {
      setSettings({
        company: { ...DEFAULT_SETTINGS.company, ...data.settings.company },
        notifications: { ...DEFAULT_SETTINGS.notifications, ...data.settings.notifications },
        profile: { ...DEFAULT_SETTINGS.profile, ...data.settings.profile },
      });
    }
  };
  const resetDemo = () => {
    setEmployees(initialEmployees);
    setLeaveData(initialLeaveData);
    setAttendanceData([]);
    setSettings({ ...DEFAULT_SETTINGS });
  };

  return (
    <div className="app-shell">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isCollapsed={sidebarCollapsed}
        setIsCollapsed={setSidebarCollapsed}
        companyName={settings.company.name}
        currentUser={currentUser}
      />

      <main className="app-main">
        <Header
          currentUser={currentUser}
          isLoggedIn={isLoggedIn}
          onLogin={() => { setIsLoggedIn(true); pushLog([{ action: "Signed in", tone: "green", detail: ADMIN.email }]); }}
          onLogout={() => { setIsLoggedIn(false); pushLog([{ action: "Signed out", tone: "amber", detail: ADMIN.email }]); }}
          onSelectResult={setActiveTab}
          employees={employees}
          alerts={alerts}
          companyName={settings.company.name}
        />

        <div key={`${activeTab}-${pageKey}`} ref={mainRef} className={`page-content page-content-${activeTab} page-enter`}>
          {activeTab === "dashboard" && (
            <DashboardOverview
              employees={employees}
              attendanceData={todayRows}
              leaveData={leaveData}
              totalEmployees={totalEmployees}
              activeCount={activeCount}
              presentToday={presentToday}
              absentToday={absentToday}
              onLeaveToday={onLeaveToday}
              pendingLeaves={pendingLeaves}
              attendancePercentage={attendancePercentage}
              departmentStats={departmentStats}
              onNavigate={setActiveTab}
            />
          )}
          {activeTab === "employee" && (
            <EmployeeModule
              employees={employees}
              setEmployees={setEmployees}
              attendanceData={todayRows}
              allAttendance={attendanceData}
              leaveData={leaveData}
              defaultDepartment={settings.company.defaultDepartment}
            />
          )}
          {activeTab === "attendance" && (
            <AttendanceModule
              attendanceData={attendanceData}
              setAttendanceData={setAttendanceData}
              employees={employees}
              leaveData={leaveData}
            />
          )}
          {activeTab === "leave" && (
            <LeaveModule leaveData={leaveData} setLeaveData={setLeaveData} employees={employees} attendanceData={todayRows} />
          )}
          {activeTab === "reports" && (
            <ReportsModule employees={employees} attendanceData={attendanceData} leaveData={leaveData} />
          )}
          {activeTab === "settings" && (
            <SettingsView
              subTab={settingsSubTab}
              setSubTab={setSettingsSubTab}
              profile={profile}
              employees={employees}
              company={settings.company}
              notifications={settings.notifications}
              onSaveProfile={saveProfile}
              onSaveCompany={saveCompany}
              onSaveNotifications={saveNotifications}
              theme={theme}
              setTheme={setTheme}
              density={density}
              setDensity={setDensity}
              accent={accent}
              setAccent={setAccent}
              accentOptions={Object.keys(ACCENTS)}
              auditLog={auditLog}
              onClearLog={() => setAuditLog([])}
              onExportBackup={exportBackup}
              onImportBackup={importBackup}
              onResetDemo={resetDemo}
              counts={{ employees: employees.length, leaves: leaveData.length, attendance: attendanceData.length }}
            />
          )}
        </div>
      </main>
    </div>
  );
}
