import React, { useState, useMemo, useCallback } from "react";
import {
  SearchIcon, EyeIcon, CalendarIcon, CloseIcon, PrintIcon,
  ChevronLeft, ChevronRight,
} from "./Icons";
import SummaryBoxes from "./SummaryBoxes";
import ViewToggle, { useStoredView } from "./ViewToggle";
import {
  todayISO, formatDate, formatDateShort, nowTime12, hasTime,
  normalizeAttendance, initials, printView, getCompanyName,
} from "../utils/helpers";

const STATUSES = ["Present", "Late", "Half-Day", "Absent", "On Leave"];
const statusClass = (s) => (s || "absent").toLowerCase().replace(/\s+/g, "-");

export default function AttendanceModule({
  attendanceData = [],
  setAttendanceData,
  employees = [],
  leaveData = [],
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [dateFilter, setDateFilter] = useState(todayISO());
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewing, setViewing] = useState(null);
  const [toast, setToast] = useState("");
  const [view, setView] = useStoredView("peopledesk_view_attendance");

  /* Names and departments always come from the employee directory */
  const rows = useMemo(
    () => attendanceData.map((r) => normalizeAttendance(r, todayISO(), employees)),
    [attendanceData, employees]
  );

  /* Summary tiles follow the selected day */
  const dayRows = useMemo(() => rows.filter((r) => !dateFilter || r.date === dateFilter), [rows, dateFilter]);

  const todayRows = useMemo(() => rows.filter((r) => r.date === todayISO()), [rows]);

  const departments = useMemo(
    () => ["All", ...Array.from(new Set(rows.map((r) => r.department).filter(Boolean))).sort()],
    [rows]
  );

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2200);
  }, []);

  /* Update one record, identified by employee id + date */
  const updateRecord = (target, patch) => {
    setAttendanceData((prev) =>
      prev.map((r) => {
        const n = normalizeAttendance(r, todayISO(), employees);
        return n.empId === target.empId && n.date === target.date ? { ...r, ...n, ...patch } : r;
      })
    );
  };

  /* Check In -> Present, stamped with the current time */
  const handleCheckIn = (rec) => {
    const time = nowTime12();
    updateRecord(rec, { checkIn: time, checkOut: "--", status: "Present", manualLeave: false, manualAbsent: false });
    showToast(`${rec.empName} checked in at ${time}`);
  };

  /* Check Out -> stamps the current time */
  const handleCheckOut = (rec) => {
    const time = nowTime12();
    updateRecord(rec, { checkOut: time });
    showToast(`${rec.empName} checked out at ${time}`);
  };

  /* X -> back to Absent (times cleared) */
  const handleAbsent = (rec) => {
    updateRecord(rec, { checkIn: "--", checkOut: "--", status: "Absent", manualLeave: false, manualAbsent: true });
    showToast(`${rec.empName} marked absent`);
  };

  /* Calendar button: Absent -> On Leave, press again -> Absent.
     Works the same for people who are On Leave by default (approved leave). */
  const handleLeave = (rec) => {
    if (rec.status === "On Leave") {
      updateRecord(rec, { checkIn: "--", checkOut: "--", status: "Absent", manualLeave: false, manualAbsent: true });
      showToast(`${rec.empName} marked Absent`);
    } else {
      updateRecord(rec, { checkIn: "--", checkOut: "--", status: "On Leave", manualLeave: true, manualAbsent: false });
      showToast(`${rec.empName} marked On Leave`);
    }
  };

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return rows.filter((r) => {
      const matchesSearch =
        !q ||
        r.empName?.toLowerCase().includes(q) ||
        r.empId?.toLowerCase().includes(q) ||
        r.department?.toLowerCase().includes(q);
      return (
        matchesSearch &&
        (departmentFilter === "All" || r.department === departmentFilter) &&
        (statusFilter === "All" || r.status === statusFilter) &&
        (!dateFilter || r.date === dateFilter)
      );
    });
  }, [rows, searchQuery, departmentFilter, statusFilter, dateFilter]);

  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / rowsPerPage));
  const page = Math.min(currentPage, totalPages);
  const startIdx = total === 0 ? 0 : (page - 1) * rowsPerPage + 1;
  const endIdx = Math.min(page * rowsPerPage, total);
  const pageRows = filtered.slice((page - 1) * rowsPerPage, page * rowsPerPage);

  const count = (s) => dayRows.filter((r) => r.status === s).length;
  const attended = count("Present") + count("Late") + count("Half-Day");
  const attendanceRate = dayRows.length ? ((attended / dayRows.length) * 100).toFixed(1) : "0.0";

  const resetPage = (setter) => (e) => {
    setter(e.target.value);
    setCurrentPage(1);
  };

  const renderActions = (r) => {
    const onLeave = r.status === "On Leave";
    const checkedIn = hasTime(r.checkIn);
    const checkedOut = hasTime(r.checkOut);
    return (
      <div className="pd-actions">
        <button type="button" className="pd-act pd-act-in" disabled={onLeave || checkedIn}
          title={onLeave ? "Employee is on leave" : checkedIn ? "Already checked in" : "Check in now (marks Present)"}
          onClick={() => handleCheckIn(r)}>Check In</button>
        <button type="button" className="pd-act pd-act-out" disabled={onLeave || !checkedIn || checkedOut}
          title={!checkedIn ? "Check in first" : checkedOut ? "Already checked out" : "Check out now"}
          onClick={() => handleCheckOut(r)}>Check Out</button>
        <button type="button" className="pd-icon-btn is-danger" disabled={onLeave || r.status === "Absent"} title="Mark absent" aria-label="Mark absent" onClick={() => handleAbsent(r)}><CloseIcon size={14} /></button>
        <button type="button" className={`pd-icon-btn ${onLeave ? "is-active" : ""}`}
          title={onLeave ? "On Leave - press to mark Absent" : "Mark On Leave"}
          aria-label="Mark On Leave" onClick={() => handleLeave(r)}><CalendarIcon size={14} /></button>
        <button type="button" className="pd-icon-btn" title="View details" aria-label="View details" onClick={() => setViewing(r)}><EyeIcon size={14} /></button>
      </div>
    );
  };

  const empInfo = (empId) => employees.find((e) => e.id === empId) || {};
  const filtersActive = searchQuery || departmentFilter !== "All" || statusFilter !== "All" || dateFilter !== todayISO();

  return (
    <div className="pd-page fit">
      {/* ---------- Header ---------- */}
      <div className="pd-page-head no-print">
        <div>
          <h2 className="pd-title">Daily attendance</h2>
          <p className="pd-sub">Everyone starts the day as Absent. Check in to mark Present, press ✕ to mark Absent, or use the calendar button to switch between On Leave and Absent.</p>
        </div>
        <div className="pd-head-actions">
          <button type="button" className="pd-btn pd-btn-action" onClick={() => window.print()}>
            <PrintIcon /> Print
          </button>
        </div>
      </div>

      {/* ---------- Filters ---------- */}
      <div className="pd-toolbar no-print">
        <div className="pd-search">
          <SearchIcon size={15} />
          <input type="search" className="pd-input" placeholder="Search employees…" value={searchQuery} onChange={resetPage(setSearchQuery)} />
        </div>
        <select className="pd-select" value={departmentFilter} onChange={resetPage(setDepartmentFilter)}>
          {departments.map((d) => <option key={d} value={d}>{d === "All" ? "All departments" : d}</option>)}
        </select>
        <select className="pd-select" value={statusFilter} onChange={resetPage(setStatusFilter)}>
          <option value="All">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <input type="date" className="pd-input pd-date" value={dateFilter} onChange={resetPage(setDateFilter)} title="Attendance date" />
        {filtersActive && (
          <button
            type="button"
            className="pd-btn pd-btn-ghost"
            onClick={() => { setSearchQuery(""); setDepartmentFilter("All"); setStatusFilter("All"); setDateFilter(todayISO()); setCurrentPage(1); }}
          >
            Reset
          </button>
        )}
        <ViewToggle value={view} onChange={setView} />
      </div>

      <SummaryBoxes employees={employees} todayRows={todayRows} />

      {/* ---------- Table (fixed header, rows scroll inside) ---------- */}
      <div className="pd-card pd-table-card no-print">
        {view === "cards" ? (
          <div className="pd-cards-wrap">
            {pageRows.length === 0 ? (
              <div className="pd-empty">No attendance records match the current filters.</div>
            ) : (
              <div className="pd-card-grid">
                {pageRows.map((r) => (
                  <article className="pd-person-card" key={`${r.empId}-${r.date}`}>
                    <div className="pd-person-top">
                      <span className="pd-avatar">{initials(r.empName)}</span>
                      <div className="pd-user-stack">
                        <span className="pd-user-name">{r.empName}</span>
                        <span className="pd-person-id">{r.empId} · {r.department}</span>
                      </div>
                      <span className={`pd-badge ${statusClass(r.status)}`}>{r.status}</span>
                    </div>
                    <div className="pd-person-meta">
                      <div><span>Check in</span><strong>{hasTime(r.checkIn) ? r.checkIn : "--"}</strong></div>
                      <div><span>Check out</span><strong>{hasTime(r.checkOut) ? r.checkOut : "--"}</strong></div>
                    </div>
                    <div className="pd-person-foot">{renderActions(r)}</div>
                  </article>
                ))}
              </div>
            )}
          </div>
        ) : (
        <div className="pd-table-wrap">
          <table className="pd-table att-table">
            <colgroup>
              <col />
              <col style={{ width: "140px" }} />
              <col style={{ width: "130px" }} />
              <col style={{ width: "130px" }} />
              <col style={{ width: "150px" }} />
              <col style={{ width: "320px" }} />
            </colgroup>
            <thead>
              <tr>
                <th>Employee</th>
                <th className="th-center">Date</th>
                <th className="th-center">Check in</th>
                <th className="th-center">Check out</th>
                <th className="th-center">Status</th>
                <th className="th-actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.length === 0 ? (
                <tr><td colSpan="6" className="pd-empty">No attendance records match the current filters.</td></tr>
              ) : (
                pageRows.map((r) => (
                  <tr key={`${r.empId}-${r.date}`}>
                    <td>
                      <div className="pd-user">
                        <span className="pd-avatar">{initials(r.empName)}</span>
                        <div className="pd-user-stack">
                          <span className="pd-user-name">{r.empName}</span>
                          <span className="pd-user-meta">{r.empId} · {r.department}</span>
                        </div>
                      </div>
                    </td>
                    <td className="td-center pd-nowrap">{formatDateShort(r.date)}</td>
                    <td className="td-center"><span className={`pd-time ${hasTime(r.checkIn) ? "" : "is-empty"}`}>{hasTime(r.checkIn) ? r.checkIn : "--"}</span></td>
                    <td className="td-center"><span className={`pd-time ${hasTime(r.checkOut) ? "" : "is-empty"}`}>{hasTime(r.checkOut) ? r.checkOut : "--"}</span></td>
                    <td className="td-center"><span className={`pd-badge ${statusClass(r.status)}`}>{r.status}</span></td>
                    <td>{renderActions(r)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        )}
        <div className="pd-footer">
          <div className="pd-showing">
            <span>Showing {startIdx}–{endIdx} of {total} employees</span>
            <span>Attendance rate {attendanceRate}% · {count("Late")} late</span>
            <label className="pd-rows">
              Rows
              <select className="pd-select pd-select-sm" value={rowsPerPage} onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}>
                {[5, 10, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>
          <div className="pd-pager">
            <button type="button" className="pd-pager-btn" disabled={page === 1} onClick={() => setCurrentPage(page - 1)}>
              <ChevronLeft /> Previous
            </button>
            <span className="pd-pager-info">{page} / {totalPages}</span>
            <button type="button" className="pd-pager-btn" disabled={page === totalPages} onClick={() => setCurrentPage(page + 1)}>
              Next <ChevronRight />
            </button>
          </div>
        </div>
      </div>

      {/* ---------- Print sheet (all filtered rows) ---------- */}
      <div className="print-only">
        <div className="pd-print-title">
          <h2>{getCompanyName()} · Attendance report</h2>
          <p>{dateFilter ? formatDate(dateFilter) : "All dates"} · {total} employees</p>
        </div>
        <table className="pd-table">
          <thead>
            <tr><th>Emp ID</th><th>Employee</th><th>Department</th><th>Date</th><th>Check in</th><th>Check out</th><th>Status</th></tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={`p-${r.empId}-${r.date}`}>
                <td>{r.empId}</td><td>{r.empName}</td><td>{r.department}</td><td>{formatDateShort(r.date)}</td>
                <td>{hasTime(r.checkIn) ? r.checkIn : "--"}</td><td>{hasTime(r.checkOut) ? r.checkOut : "--"}</td><td>{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ---------- View modal (printable) ---------- */}
      {viewing && (() => {
        const info = empInfo(viewing.empId);
        const current = rows.find((r) => r.empId === viewing.empId && r.date === viewing.date) || viewing;
        const leaves = leaveData.filter((l) => (l.empId || l.id) === viewing.empId).length;
        return (
          <div className="pd-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setViewing(null)}>
            <div className="pd-modal print-area">
              <div className="print-only pd-print-title">
                <h2>{getCompanyName()} · Attendance record</h2>
              </div>
              <div className="pd-modal-head">
                <div className="pd-user">
                  <span className="pd-avatar pd-avatar-lg">{initials(current.empName)}</span>
                  <div>
                    <h3>{current.empName}</h3>
                    <p>{info.designation || "Employee"} · {current.department}</p>
                  </div>
                </div>
                <button type="button" className="pd-icon-btn no-print" onClick={() => setViewing(null)} aria-label="Close"><CloseIcon /></button>
              </div>
              <div className="pd-modal-body">
                <div className="pd-detail-grid">
                  <div><span>Employee ID</span><strong>{current.empId}</strong></div>
                  <div><span>Status</span><strong><span className={`pd-badge ${statusClass(current.status)}`}>{current.status}</span></strong></div>
                  <div><span>Date</span><strong>{formatDate(current.date)}</strong></div>
                  <div><span>Employment status</span><strong>{info.status || "—"}</strong></div>
                  <div><span>Check in</span><strong>{hasTime(current.checkIn) ? current.checkIn : "--"}</strong></div>
                  <div><span>Check out</span><strong>{hasTime(current.checkOut) ? current.checkOut : "--"}</strong></div>
                  <div><span>Email</span><strong>{info.email || "—"}</strong></div>
                  <div><span>Joined</span><strong>{info.joined ? formatDate(info.joined) : "—"}</strong></div>
                  <div><span>Leave requests</span><strong>{leaves}</strong></div>
                </div>
              </div>
              <div className="pd-modal-foot no-print">
                <button type="button" className="pd-btn" onClick={() => setViewing(null)}>Close</button>
                <button type="button" className="pd-btn pd-btn-action" onClick={printView}><PrintIcon /> Print</button>
              </div>
            </div>
          </div>
        );
      })()}

      {toast && <div className="pd-toast no-print" role="status">{toast}</div>}
    </div>
  );
}
