import React, { useMemo } from "react";
import { initials, formatDateShort, formatDateRange, minutesOf, hasTime, normalizeLeave, todayISO } from "../utils/helpers";

const DEPT_COLORS = ["#2563eb", "#0d9488", "#7c3aed", "#d97706", "#db2777", "#0891b2", "#65a30d", "#475569"];

function Kpi({ tone, label, value, hint, onClick }) {
  return (
    <button type="button" className={`kpi kpi-${tone}`} onClick={onClick}>
      <span className="kpi-label">{label}</span>
      <strong className="kpi-value">{value}</strong>
      <span className="kpi-hint">{hint}</span>
    </button>
  );
}

export default function DashboardOverview({
  employees = [],
  attendanceData = [],
  leaveData = [],
  totalEmployees = 0,
  activeCount = 0,
  presentToday = 0,
  absentToday = 0,
  onLeaveToday = 0,
  pendingLeaves = 0,
  attendancePercentage = "0.0%",
  departmentStats = [],
  onNavigate,
}) {
  const go = (tab) => () => onNavigate && onNavigate(tab);
  const maxDept = Math.max(...departmentStats.map((d) => d.count), 1);
  const pct = parseFloat(attendancePercentage) || 0;

  /* Ring chart */
  const R = 52;
  const C = 2 * Math.PI * R;

  /* Real activity feed built from the actual data */
  const activities = useMemo(() => {
    const items = [];

    attendanceData
      .filter((a) => hasTime(a.checkIn))
      .sort((a, b) => minutesOf(b.checkOut !== "--" ? b.checkOut : b.checkIn) - minutesOf(a.checkOut !== "--" ? a.checkOut : a.checkIn))
      .slice(0, 4)
      .forEach((a) => {
        const out = hasTime(a.checkOut);
        items.push({
          key: `att-${a.empId}`,
          name: a.empName,
          title: out ? "Checked out" : "Checked in",
          detail: `${a.department} · ${out ? a.checkOut : a.checkIn}`,
          badge: a.status,
          tone: a.status === "Late" ? "amber" : "green",
        });
      });

    leaveData
      .map((l) => normalizeLeave(l, employees))
      .slice(-3)
      .reverse()
      .forEach((l) =>
        items.push({
          key: `lv-${l.leaveId}`,
          name: l.empName,
          title: `${l.leaveType} request`,
          detail: `${formatDateShort(l.startDate)} – ${formatDateShort(l.endDate)}`,
          badge: l.status,
          tone: l.status === "Approved" ? "green" : l.status === "Rejected" ? "red" : "amber",
        })
      );

    [...employees]
      .filter((e) => e.joined)
      .sort((a, b) => String(b.joined).localeCompare(String(a.joined)))
      .slice(0, 2)
      .forEach((e) =>
        items.push({
          key: `hire-${e.id}`,
          name: e.name,
          title: "Joined the team",
          detail: `${e.designation || "Employee"} · ${e.department} · ${formatDateShort(e.joined)}`,
          badge: "New hire",
          tone: "blue",
        })
      );

    return items.slice(0, 8);
  }, [attendanceData, leaveData, employees]);

  /* Who is away now or soon (approved leave that has not ended yet) */
  const whoIsOut = useMemo(() => {
    const today = todayISO();
    return leaveData
      .map((l) => normalizeLeave(l, employees))
      .filter((l) => l.status === "Approved" && l.endDate >= today)
      .sort((a, b) => a.startDate.localeCompare(b.startDate))
      .slice(0, 5)
      .map((l) => ({ ...l, now: l.startDate <= today }));
  }, [leaveData, employees]);

  /* Work anniversaries falling in the current month */
  const anniversaries = useMemo(() => {
    const t = new Date();
    return employees
      .filter((e) => e.joined)
      .map((e) => {
        const d = new Date(`${e.joined}T00:00:00`);
        return { e, day: d.getDate(), month: d.getMonth(), years: t.getFullYear() - d.getFullYear() };
      })
      .filter((x) => !Number.isNaN(x.day) && x.month === t.getMonth() && x.years > 0)
      .sort((a, b) => a.day - b.day)
      .slice(0, 5);
  }, [employees]);
  const monthName = new Date().toLocaleDateString("en-GB", { month: "long" });

  const longDate = new Date(`${todayISO()}T00:00:00`).toLocaleDateString("en-GB", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });

  return (
    <div className="dashboard">
      <div className="pd-page-head">
        <div>
          <h2 className="pd-title">Dashboard overview</h2>
          <p className="pd-sub">Workforce summary for {longDate}.</p>
        </div>
      </div>


      <div className="kpi-grid">
        <Kpi tone="blue" label="Total employees" value={totalEmployees} hint={`${activeCount} active`} onClick={go("employee")} />
        <Kpi tone="green" label="Present today" value={presentToday} hint={`${attendancePercentage} attendance`} onClick={go("attendance")} />
        <Kpi tone="red" label="Absent" value={absentToday} hint="Not checked in today" onClick={go("attendance")} />
        <Kpi tone="violet" label="On leave" value={onLeaveToday} hint="On approved leave today" onClick={go("attendance")} />
      </div>

      <div className="dash-grid">
        <section className="pd-card pd-panel">
          <div className="panel-head">
            <div>
              <h3>Workforce by department</h3>
              <p className="pd-panel-sub">{departmentStats.length} departments · {totalEmployees} employees</p>
            </div>
            <button type="button" className="pd-btn pd-btn-ghost" onClick={go("reports")}>Detailed report</button>
          </div>
          {departmentStats.length === 0 && <div className="pd-empty">No employees yet.</div>}
          {departmentStats.map((d, i) => (
            <div key={d.name} className="pd-bar-row">
              <span className="pd-bar-label">{d.name}</span>
              <div className="pd-bar-track">
                <div className="pd-bar-fill" style={{ width: `${(d.count / maxDept) * 100}%`, background: DEPT_COLORS[i % DEPT_COLORS.length] }} />
              </div>
              <span className="pd-bar-value">
                {d.count} <small>({totalEmployees ? Math.round((d.count / totalEmployees) * 100) : 0}%)</small>
              </span>
            </div>
          ))}
        </section>

        <section className="pd-card pd-panel">
          <div className="panel-head">
            <div>
              <h3>Today's attendance</h3>
              <p className="pd-panel-sub">Live from the attendance register</p>
            </div>
          </div>
          <div className="pd-donut-row">
            <div className="pd-donut">
              <svg viewBox="0 0 120 120" role="img" aria-label={`Attendance ${attendancePercentage}`}>
                <circle cx="60" cy="60" r={R} fill="none" stroke="var(--line-soft)" strokeWidth="10" />
                {pct > 0 && (
                  <circle
                    cx="60" cy="60" r={R} fill="none" stroke="var(--green)" strokeWidth="10" strokeLinecap="round"
                    strokeDasharray={`${(pct / 100) * C} ${C}`} transform="rotate(-90 60 60)"
                  />
                )}
              </svg>
              <div className="pd-donut-center"><strong>{attendancePercentage}</strong><span>Present</span></div>
            </div>
            <ul className="pd-legend">
              <li><i style={{ background: "var(--green)" }} /><span>Present / late</span><b>{presentToday}</b></li>
              <li><i style={{ background: "var(--red)" }} /><span>Absent</span><b>{absentToday}</b></li>
              <li><i style={{ background: "var(--violet)" }} /><span>On leave</span><b>{onLeaveToday}</b></li>
              <li><i style={{ background: "var(--slate)" }} /><span>Total staff</span><b>{totalEmployees}</b></li>
            </ul>
          </div>
        </section>

        <section className="pd-card pd-panel">
          <div className="panel-head">
            <div>
              <h3>Who's out</h3>
              <p className="pd-panel-sub">Approved leave happening now or coming up</p>
            </div>
            <button type="button" className="pd-btn pd-btn-ghost" onClick={go("leave")}>All leave</button>
          </div>
          {whoIsOut.length === 0 ? (
            <div className="pd-empty">Nobody is on approved leave.</div>
          ) : (
            <ul className="activity-list">
              {whoIsOut.map((l) => (
                <li key={l.leaveId}>
                  <span className="pd-avatar">{initials(l.empName)}</span>
                  <div className="activity-text">
                    <strong>{l.empName} <em>{l.leaveType}</em></strong>
                    <span>{formatDateRange(l.startDate, l.endDate)}</span>
                  </div>
                  <span className={`tag ${l.now ? "tag-amber" : "tag-blue"}`}>{l.now ? "Away now" : "Upcoming"}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="pd-card pd-panel">
          <div className="panel-head">
            <div>
              <h3>Work anniversaries</h3>
              <p className="pd-panel-sub">Team milestones in {monthName}</p>
            </div>
          </div>
          {anniversaries.length === 0 ? (
            <div className="pd-empty">No work anniversaries this month.</div>
          ) : (
            <ul className="activity-list">
              {anniversaries.map(({ e, day, years }) => (
                <li key={e.id}>
                  <span className="pd-avatar">{initials(e.name)}</span>
                  <div className="activity-text">
                    <strong>{e.name} <em>{e.designation || e.department}</em></strong>
                    <span>{day} {monthName}</span>
                  </div>
                  <span className="tag tag-green">{years} {years === 1 ? "year" : "years"}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="pd-card pd-panel dash-wide">
          <div className="panel-head">
            <div>
              <h3>Recent activity</h3>
              <p className="pd-panel-sub">Check-ins, leave requests and new joiners</p>
            </div>
          </div>
          {activities.length === 0 ? (
            <div className="pd-empty">No activity yet today. Check-ins will appear here.</div>
          ) : (
            <ul className="activity-list">
              {activities.map((a) => (
                <li key={a.key}>
                  <span className="pd-avatar">{initials(a.name)}</span>
                  <div className="activity-text">
                    <strong>{a.name} <em>{a.title}</em></strong>
                    <span>{a.detail}</span>
                  </div>
                  <span className={`tag tag-${a.tone}`}>{a.badge}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
