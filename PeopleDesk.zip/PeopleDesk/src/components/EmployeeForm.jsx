import React from "react";

export default function EmployeeForm({
  formData,
  handleChange,
  handleSubmit,
  editingId,
  errorMessage,
  onClose
}) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(15, 23, 42, 0.7)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 100000,
        padding: "0"
      }}
    >
      <div
        style={{
          width: "100vw",
          height: "100vh",
          backgroundColor: "#ffffff",
          display: "flex",
          flexDirection: "column",
          boxSizing: "border-box",
          overflowY: "auto"
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "24px 48px",
            borderBottom: "1px solid #e2e8f0",
            backgroundColor: "#ffffff"
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontSize: "24px", fontWeight: 800, color: "#0f172a" }}>
              {editingId ? "Edit Employee Profile" : "Register New Employee"}
            </h2>
            <p style={{ margin: "4px 0 0 0", fontSize: "14px", color: "#64748b" }}>
              Complete the details below to update or register workforce records across the system.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: "8px",
              padding: "8px 16px",
              fontSize: "14px",
              fontWeight: 700,
              cursor: "pointer",
              color: "#334155"
            }}
          >
            ✕ Close
          </button>
        </div>

        <div style={{ flex: 1, padding: "48px", display: "flex", justifyContent: "center", backgroundColor: "#ffffff" }}>
          <form
            onSubmit={handleSubmit}
            style={{
              width: "100%",
              maxWidth: "1000px",
              display: "flex",
              flexDirection: "column",
              gap: "28px"
            }}
          >
            {errorMessage && (
              <div
                style={{
                  backgroundColor: "#fef2f2",
                  border: "1px solid #fecaca",
                  color: "#dc2626",
                  padding: "14px 18px",
                  borderRadius: "8px",
                  fontSize: "14px",
                  fontWeight: 600
                }}
              >
                ⚠️ {errorMessage}
              </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "28px" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Full Name *</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="e.g. Alex Morgan"
                  required
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    fontSize: "15px",
                    outline: "none"
                  }}
                />
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Email Address *</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="e.g. alex.m@peopledesk.com"
                  required
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    fontSize: "15px",
                    outline: "none"
                  }}
                />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "28px" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Department *</label>
                <select
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    fontSize: "15px",
                    outline: "none",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    cursor: "pointer"
                  }}
                >
                  <option value="Engineering">Engineering</option>
                  <option value="Design">Design</option>
                  <option value="Sales">Sales</option>
                  <option value="Finance">Finance</option>
                  <option value="IT">IT</option>
                  <option value="HR">HR</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Operations">Operations</option>
                </select>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Designation / Job Role *</label>
                <input
                  type="text"
                  name="designation"
                  value={formData.designation}
                  onChange={handleChange}
                  placeholder="e.g. Lead Frontend Developer"
                  required
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    fontSize: "15px",
                    outline: "none"
                  }}
                />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "28px" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Age (Years: 18 - 60) *</label>
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleChange}
                  placeholder="e.g. 29"
                  min="18"
                  max="60"
                  required
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    fontSize: "15px",
                    outline: "none"
                  }}
                />
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <label style={{ fontSize: "14px", fontWeight: 700, color: "#334155" }}>Employment Status *</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  style={{
                    padding: "14px 18px",
                    borderRadius: "8px",
                    border: "1.5px solid #cbd5e1",
                    fontSize: "15px",
                    outline: "none",
                    backgroundColor: "#ffffff",
                    color: "#0f172a",
                    cursor: "pointer"
                  }}
                >
                  <option value="Active">Active</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: "16px", marginTop: "24px" }}>
              <button
                type="button"
                onClick={onClose}
                style={{
                  padding: "14px 28px",
                  borderRadius: "8px",
                  border: "1px solid #cbd5e1",
                  backgroundColor: "#ffffff",
                  color: "#334155",
                  fontSize: "15px",
                  fontWeight: 600,
                  cursor: "pointer"
                }}
              >
                Cancel
              </button>
              <button
                type="submit"
                style={{
                  padding: "14px 36px",
                  borderRadius: "8px",
                  border: "none",
                  backgroundColor: "#4f46e5",
                  color: "#ffffff",
                  fontSize: "15px",
                  fontWeight: 700,
                  cursor: "pointer",
                  boxShadow: "0 4px 12px rgba(79, 70, 229, 0.3)"
                }}
              >
                {editingId ? "Save Changes" : "Create Employee Record"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}