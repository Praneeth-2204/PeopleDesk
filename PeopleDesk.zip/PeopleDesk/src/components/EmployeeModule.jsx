import React, { useState, useMemo, useEffect } from "react";
import {
  SearchIcon, EyeIcon, EditIcon, TrashIcon, CloseIcon, PrintIcon, PlusIcon,
  CheckIcon, ChevronLeft, ChevronRight,
} from "./Icons";
import {
  formatDateShort, formatDate, tenure, todayISO, initials, printView, getCompanyName,
  normalizeAttendance, normalizeLeave, daysBetween, formatDateRange, employeeMailLink,
} from "../utils/helpers";
import { ADMIN } from "../config";
import SummaryBoxes from "./SummaryBoxes";
import ViewToggle, { useStoredView } from "./ViewToggle";

const MailIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="3" y="5" width="18" height="14" rx="2" /><polyline points="3 7 12 13 21 7" />
  </svg>
);

const BASE_DEPARTMENTS = ["Engineering", "Design", "Sales", "Finance", "IT", "HR", "Marketing", "Operations"];
const STATUSES = ["Active", "On Leave", "Inactive"];
const statusClass = (s) => (s || "inactive").toLowerCase().replace(/\s+/g, "-");

function EmployeeFormFields({ value, onChange, departments, idReadOnly }) {
  const set = (k) => (e) => onChange({ ...value, [k]: e.target.value });
  return (
    <div className="pd-modal-body pd-form-grid">
      <label className="pd-field">
        <span>Employee ID *</span>
        <input className="pd-input" value={value.id} onChange={set("id")} readOnly={idReadOnly} />
      </label>
      <label className="pd-field">
        <span>Full name *</span>
        <input className="pd-input" value={value.name} onChange={set("name")} placeholder="e.g. Jane Cooper" />
      </label>
      <label className="pd-field">
        <span>Email address *</span>
        <input type="email" className="pd-input" value={value.email} onChange={set("email")} placeholder="name@company.com" />
      </label>
      <label className="pd-field">
        <span>Job role / designation</span>
        <input className="pd-input" value={value.designation || ""} onChange={set("designation")} />
      </label>
      <label className="pd-field">
        <span>Department</span>
        <select className="pd-select" value={value.department} onChange={set("department")}>
          {departments.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
      </label>
      <label className="pd-field">
        <span>Status</span>
        <select className="pd-select" value={value.status} onChange={set("status")}>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </label>
      <label className="pd-field pd-span-2">
        <span>Date of joining *</span>
        <input type="date" className="pd-input" value={value.joined || ""} onChange={set("joined")} />
      </label>
    </div>
  );
}

export default function EmployeeModule({
  employees = [],
  setEmployees,
  attendanceData = [],
  allAttendance = [],
  leaveData = [],
  defaultDepartment = "Engineering",
}) {
  const [view, setView] = useStoredView("peopledesk_view_employee");
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [designationFilter, setDesignationFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [sortKey, setSortKey] = useState("");
  const [sortDir, setSortDir] = useState("asc");
  const [adding, setAdding] = useState(null);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [error, setError] = useState("");

  const departments = useMemo(
    () => Array.from(new Set([...BASE_DEPARTMENTS, defaultDepartment, ...employees.map((e) => e.department).filter(Boolean)])).sort(),
    [employees, defaultDepartment]
  );
  const designations = useMemo(
    () => ["All", ...Array.from(new Set(employees.map((e) => e.designation).filter(Boolean))).sort()],
    [employees]
  );

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { setAdding(null); setEditing(null); setViewing(null); setError(""); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return employees.filter((emp) => {
      const matchesSearch =
        !q ||
        emp.name?.toLowerCase().includes(q) ||
        emp.id?.toLowerCase().includes(q) ||
        emp.email?.toLowerCase().includes(q) ||
        emp.department?.toLowerCase().includes(q) ||
        emp.designation?.toLowerCase().includes(q);
      return (
        matchesSearch &&
        (departmentFilter === "All" || emp.department === departmentFilter) &&
        (designationFilter === "All" || emp.designation === designationFilter) &&
        (statusFilter === "All" || emp.status === statusFilter)
      );
    });
  }, [employees, searchQuery, departmentFilter, designationFilter, statusFilter]);

  const sorted = useMemo(() => {
    if (!sortKey) return filtered;
    const dir = sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) =>
      String(a[sortKey] ?? "").toLowerCase().localeCompare(String(b[sortKey] ?? "").toLowerCase(), undefined, { numeric: true }) * dir
    );
  }, [filtered, sortKey, sortDir]);

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("asc"); }
    setCurrentPage(1);
  };
  const mark = (key) => (sortKey === key ? (sortDir === "asc" ? " ▲" : " ▼") : "");

  const total = sorted.length;
  const totalPages = Math.max(1, Math.ceil(total / recordsPerPage));
  const page = Math.min(currentPage, totalPages);
  const startIdx = total === 0 ? 0 : (page - 1) * recordsPerPage + 1;
  const endIdx = Math.min(page * recordsPerPage, total);
  const pageRows = sorted.slice((page - 1) * recordsPerPage, page * recordsPerPage);

  const resetPage = (setter) => (e) => { setter(e.target.value); setCurrentPage(1); };

  const openAdd = () => {
    const next = employees.reduce((max, e) => {
      const n = parseInt(String(e.id).replace(/\D/g, ""), 10);
      return Number.isNaN(n) ? max : Math.max(max, n);
    }, 0) + 1;
    setError("");
    setAdding({ id: `EMP-${String(next).padStart(3, "0")}`, name: "", email: "", department: defaultDepartment, designation: "", joined: todayISO(), status: "Active" });
  };

  const validate = (emp) => {
    if (!emp.id?.trim() || !emp.name?.trim() || !emp.email?.trim()) return "Employee ID, full name and email are required.";
    if (!emp.joined) return "Joining date is required.";
    return "";
  };

  const submitAdd = (e) => {
    e.preventDefault();
    const msg = validate(adding);
    if (msg) return setError(msg);
    if (employees.some((x) => x.id.toLowerCase() === adding.id.trim().toLowerCase())) return setError(`Employee ID '${adding.id}' already exists.`);
    setEmployees((prev) => [{ ...adding, id: adding.id.trim(), name: adding.name.trim(), email: adding.email.trim() }, ...prev]);
    setAdding(null);
    setError("");
  };

  const submitEdit = (e) => {
    e.preventDefault();
    const msg = validate(editing);
    if (msg) return setError(msg);
    setEmployees((prev) => prev.map((x) => (x.id === editing.id ? { ...editing, name: editing.name.trim(), email: editing.email.trim() } : x)));
    setEditing(null);
    setError("");
  };

  const remove = (emp) => {
    if (!window.confirm(`Delete ${emp.name} (${emp.id})? Their attendance and leave records will be removed too.`)) return;
    setEmployees((prev) => prev.filter((x) => x.id !== emp.id));
  };

  const current = viewing ? employees.find((e) => e.id === viewing.id) || viewing : null;

  /* Attendance + leave history for the profile dialog (last 30 days) */
  const history = useMemo(() => {
    if (!current) return null;
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
    const cut = `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, "0")}-${String(cutoff.getDate()).padStart(2, "0")}`;
    const mine = allAttendance
      .map((r) => normalizeAttendance(r, todayISO(), employees))
      .filter((r) => r.empId === current.id && r.date >= cut);
    const n = (st) => mine.filter((r) => r.status === st).length;
    const leaves = leaveData
      .map((l) => normalizeLeave(l, employees))
      .filter((l) => l.empId === current.id)
      .sort((a, b) => String(b.startDate).localeCompare(String(a.startDate)));
    const approvedDays = leaves.filter((l) => l.status === "Approved").reduce((sum, l) => sum + daysBetween(l.startDate, l.endDate), 0);
    return { present: n("Present") + n("Half-Day"), late: n("Late"), absent: n("Absent"), onLeave: n("On Leave"), leaves: leaves.slice(0, 4), approvedDays };
  }, [current, allAttendance, leaveData, employees]);

  /* Row / card actions: view, edit, email (new) and delete */
  const renderActions = (emp) => (
    <div className="pd-actions">
      <button type="button" className="pd-icon-btn" title="View profile" aria-label="View profile" onClick={() => setViewing(emp)}><EyeIcon size={14} /></button>
      <button type="button" className="pd-icon-btn" title="Edit" aria-label="Edit" onClick={() => { setError(""); setEditing({ ...emp }); }}><EditIcon size={14} /></button>
      <a className="pd-icon-btn" title={`Email ${emp.name}'s details to ${ADMIN.email}`} aria-label="Email employee details to me" href={employeeMailLink(emp, ADMIN.email)}><MailIcon /></a>
      <button type="button" className="pd-icon-btn is-danger" title="Delete" aria-label="Delete" onClick={() => remove(emp)}><TrashIcon size={14} /></button>
    </div>
  );

  return (
    <div className="pd-page fit">
      <div className="pd-page-head no-print">
        <div>
          <h2 className="pd-title">Employee directory</h2>
          <p className="pd-sub">Manage your workforce records, roles and employment status.</p>
        </div>
        <div className="pd-head-actions">
          <button type="button" className="pd-btn pd-btn-action" onClick={() => window.print()}><PrintIcon /> Print list</button>
          <button type="button" className="pd-btn pd-btn-primary" onClick={openAdd}><PlusIcon /> Add employee</button>
        </div>
      </div>

      <div className="pd-toolbar no-print">
        <div className="pd-search">
          <SearchIcon size={15} />
          <input type="search" className="pd-input" placeholder="Search name, ID, email, role…" value={searchQuery} onChange={resetPage(setSearchQuery)} />
        </div>
        <select className="pd-select" value={departmentFilter} onChange={resetPage(setDepartmentFilter)}>
          <option value="All">All departments</option>
          {departments.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select className="pd-select" value={designationFilter} onChange={resetPage(setDesignationFilter)}>
          {designations.map((d) => <option key={d} value={d}>{d === "All" ? "All designations" : d}</option>)}
        </select>
        <select className="pd-select" value={statusFilter} onChange={resetPage(setStatusFilter)}>
          <option value="All">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        {(searchQuery || departmentFilter !== "All" || designationFilter !== "All" || statusFilter !== "All") && (
          <button
            type="button"
            className="pd-btn pd-btn-ghost"
            onClick={() => { setSearchQuery(""); setDepartmentFilter("All"); setDesignationFilter("All"); setStatusFilter("All"); setCurrentPage(1); }}
          >
            Reset
          </button>
        )}
        <ViewToggle value={view} onChange={setView} />
      </div>

      <SummaryBoxes employees={employees} todayRows={attendanceData} />

      {/* Fixed header: only the rows scroll */}
      <div className="pd-card pd-table-card no-print">
        {view === "cards" ? (
          <div className="pd-cards-wrap">
            {pageRows.length === 0 ? (
              <div className="pd-empty">No employees match the current filters.</div>
            ) : (
              <div className="pd-card-grid">
                {pageRows.map((emp) => (
                  <article className="pd-person-card" key={emp.id}>
                    <div className="pd-person-top">
                      <span className="pd-avatar">{initials(emp.name)}</span>
                      <div className="pd-user-stack">
                        <span className="pd-user-name">{emp.name}</span>
                        <span className="pd-person-id">{emp.id}</span>
                      </div>
                      <span className={`pd-badge ${statusClass(emp.status)}`}>{emp.status}</span>
                    </div>
                    <div className="pd-person-meta">
                      <div><span>Department</span><strong>{emp.department}</strong></div>
                      <div><span>Designation</span><strong>{emp.designation || "—"}</strong></div>
                      <div><span>Joined</span><strong>{formatDateShort(emp.joined)}</strong></div>
                      <div><span>Email</span><strong title={emp.email}>{emp.email}</strong></div>
                    </div>
                    <div className="pd-person-foot">{renderActions(emp)}</div>
                  </article>
                ))}
              </div>
            )}
          </div>
        ) : (
        <div className="pd-table-wrap">
          <table className="pd-table emp-table">
            <colgroup>
              <col style={{ width: "8%" }} />
              <col style={{ width: "25%" }} />
              <col style={{ width: "12%" }} />
              <col style={{ width: "16%" }} />
              <col style={{ width: "11%" }} />
              <col style={{ width: "10%" }} />
              <col style={{ width: "18%" }} />
            </colgroup>
            <thead>
              <tr>
                <th className="sortable" onClick={() => toggleSort("id")}>Emp ID{mark("id")}</th>
                <th className="sortable" onClick={() => toggleSort("name")}>Name &amp; contact{mark("name")}</th>
                <th className="sortable" onClick={() => toggleSort("department")}>Department{mark("department")}</th>
                <th className="sortable" onClick={() => toggleSort("designation")}>Designation{mark("designation")}</th>
                <th className="sortable" onClick={() => toggleSort("joined")}>Joined{mark("joined")}</th>
                <th>Status</th>
                <th className="th-actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.length === 0 ? (
                <tr><td colSpan="7" className="pd-empty">No employees match the current filters.</td></tr>
              ) : (
                pageRows.map((emp) => (
                  <tr key={emp.id}>
                    <td className="pd-mono">{emp.id}</td>
                    <td>
                      <div className="pd-user">
                        <span className="pd-avatar">{initials(emp.name)}</span>
                        <div className="pd-user-stack">
                          <span className="pd-user-name">{emp.name}</span>
                          <span className="pd-user-meta">{emp.email}</span>
                        </div>
                      </div>
                    </td>
                    <td>{emp.department}</td>
                    <td>{emp.designation || "—"}</td>
                    <td>{formatDateShort(emp.joined)}</td>
                    <td><span className={`pd-badge ${statusClass(emp.status)}`}>{emp.status}</span></td>
                    <td>
                      {renderActions(emp)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        )}
        <div className="pd-footer">
          <div className="pd-showing">
            <span>Showing {startIdx}–{endIdx} of {total} employees</span>
            <label className="pd-rows">
              Rows
              <select className="pd-select pd-select-sm" value={recordsPerPage} onChange={(e) => { setRecordsPerPage(Number(e.target.value)); setCurrentPage(1); }}>
                {[5, 10, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>
          <div className="pd-pager">
            <button type="button" className="pd-pager-btn" disabled={page === 1} onClick={() => setCurrentPage(page - 1)}><ChevronLeft /> Previous</button>
            <span className="pd-pager-info">{page} / {totalPages}</span>
            <button type="button" className="pd-pager-btn" disabled={page === totalPages} onClick={() => setCurrentPage(page + 1)}>Next <ChevronRight /></button>
          </div>
        </div>
      </div>

      {/* Print sheet: every filtered employee */}
      <div className="print-only">
        <div className="pd-print-title">
          <h2>{getCompanyName()} · Employee directory</h2>
          <p>{total} employees · printed {formatDate(todayISO())}</p>
        </div>
        <table className="pd-table">
          <thead><tr><th>Emp ID</th><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Joined</th><th>Status</th></tr></thead>
          <tbody>
            {sorted.map((e) => (
              <tr key={`p-${e.id}`}>
                <td>{e.id}</td><td>{e.name}</td><td>{e.email}</td><td>{e.department}</td><td>{e.designation || "—"}</td><td>{formatDateShort(e.joined)}</td><td>{e.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add */}
      {adding && (
        <div className="pd-modal-backdrop no-print" onMouseDown={(e) => e.target === e.currentTarget && setAdding(null)}>
          <form className="pd-modal" onSubmit={submitAdd} noValidate>
            <div className="pd-modal-head">
              <div><h3>Add employee</h3><p>New employees appear in attendance automatically (Absent by default).</p></div>
              <button type="button" className="pd-icon-btn" onClick={() => setAdding(null)} aria-label="Close"><CloseIcon /></button>
            </div>
            {error && <div className="pd-alert">{error}</div>}
            <EmployeeFormFields value={adding} onChange={setAdding} departments={departments} />
            <div className="pd-modal-foot">
              <button type="button" className="pd-btn" onClick={() => setAdding(null)}>Cancel</button>
              <button type="submit" className="pd-btn pd-btn-primary"><CheckIcon size={14} /> Add employee</button>
            </div>
          </form>
        </div>
      )}

      {/* Edit */}
      {editing && (
        <div className="pd-modal-backdrop no-print" onMouseDown={(e) => e.target === e.currentTarget && setEditing(null)}>
          <form className="pd-modal" onSubmit={submitEdit} noValidate>
            <div className="pd-modal-head">
              <div><h3>Edit employee</h3><p>Changes update attendance, leave, reports and settings everywhere.</p></div>
              <button type="button" className="pd-icon-btn" onClick={() => setEditing(null)} aria-label="Close"><CloseIcon /></button>
            </div>
            {error && <div className="pd-alert">{error}</div>}
            <EmployeeFormFields value={editing} onChange={setEditing} departments={departments} idReadOnly />
            <div className="pd-modal-foot">
              <button type="button" className="pd-btn" onClick={() => setEditing(null)}>Cancel</button>
              <button type="submit" className="pd-btn pd-btn-primary"><CheckIcon size={14} /> Save changes</button>
            </div>
          </form>
        </div>
      )}

      {/* View (printable) */}
      {current && (
        <div className="pd-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setViewing(null)}>
          <div className="pd-modal print-area">
            <div className="print-only pd-print-title">
              <h2>{getCompanyName()} · Employee profile</h2>
              <p>Printed {formatDate(todayISO())}</p>
            </div>
            <div className="pd-modal-head">
              <div className="pd-user">
                <span className="pd-avatar pd-avatar-lg">{initials(current.name)}</span>
                <div>
                  <h3>{current.name}</h3>
                  <p>{current.designation || "Staff"} · {current.id}</p>
                </div>
              </div>
              <button type="button" className="pd-icon-btn no-print" onClick={() => setViewing(null)} aria-label="Close"><CloseIcon /></button>
            </div>
            <div className="pd-modal-body">
              <div className="pd-detail-grid">
                <div><span>Employee ID</span><strong>{current.id}</strong></div>
                <div><span>Status</span><strong><span className={`pd-badge ${statusClass(current.status)}`}>{current.status}</span></strong></div>
                <div><span>Email</span><strong>{current.email}</strong></div>
                <div><span>Department</span><strong>{current.department}</strong></div>
                <div><span>Designation</span><strong>{current.designation || "—"}</strong></div>
                <div><span>Date of joining</span><strong>{formatDate(current.joined)}</strong></div>
                <div className="pd-span-2"><span>Length of service</span><strong>{tenure(current.joined)}</strong></div>
              </div>
              {history && (
                <>
                  <h4 className="pd-subhead">Attendance · last 30 days</h4>
                  <div className="pd-mini-stats" style={{ marginTop: 0 }}>
                    <div><span>Present</span><strong>{history.present}</strong></div>
                    <div><span>Late</span><strong>{history.late}</strong></div>
                    <div><span>Absent</span><strong>{history.absent}</strong></div>
                    <div><span>On leave</span><strong>{history.onLeave}</strong></div>
                  </div>
                  <h4 className="pd-subhead">Leave history · {history.approvedDays} approved day(s)</h4>
                  {history.leaves.length === 0 ? (
                    <p className="pd-sub">No leave requests yet.</p>
                  ) : (
                    <ul className="pd-mini-list">
                      {history.leaves.map((l) => (
                        <li key={l.leaveId}><span>{l.leaveType} · {formatDateRange(l.startDate, l.endDate)}</span><em>{l.status}</em></li>
                      ))}
                    </ul>
                  )}
                </>
              )}
              <div className="print-only signature-row">
                <div><i />Employee signature</div>
                <div><i />Authorised HR</div>
              </div>
            </div>
            <div className="pd-modal-foot no-print">
              <button type="button" className="pd-btn" onClick={() => setViewing(null)}>Close</button>
              <a className="pd-btn pd-btn-action" href={employeeMailLink(current, ADMIN.email)} title={`Opens an email to ${ADMIN.email} with these details`}><MailIcon size={15} /> Email details to me</a>
              <button type="button" className="pd-btn pd-btn-action" onClick={printView}><PrintIcon /> Print profile</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
