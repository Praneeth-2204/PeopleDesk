import React, { useState, useRef, useEffect } from "react";
import { SearchIcon } from "./Icons";
import { initials } from "../utils/helpers";

const BellIcon = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);
const ChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

export default function Header({
  currentUser = "Administrator",
  isLoggedIn = true,
  onLogin,
  onLogout,
  onSelectResult,
  employees = [],
  alerts = [],
  companyName = "Employee Management System",
}) {
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);
  const searchRef = useRef(null);
  const searchInputRef = useRef(null);
  const menuRef = useRef(null);
  const bellRef = useRef(null);

  const results = query.trim()
    ? employees
        .filter((e) => {
          const q = query.trim().toLowerCase();
          return (
            e.name?.toLowerCase().includes(q) ||
            String(e.id ?? "").toLowerCase().includes(q) ||
            e.department?.toLowerCase().includes(q)
          );
        })
        .slice(0, 6)
    : [];

  useEffect(() => {
    const onDown = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) setSearchOpen(false);
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
      if (bellRef.current && !bellRef.current.contains(e.target)) setBellOpen(false);
    };
    const onKey = (e) => {
      if (e.key === "Escape") { setSearchOpen(false); setMenuOpen(false); setBellOpen(false); }
      /* Ctrl/Cmd + K jumps straight to the search box */
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchInputRef.current && searchInputRef.current.focus();
        setSearchOpen(true);
      }
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const pick = () => {
    setSearchOpen(false);
    setQuery("");
    onSelectResult && onSelectResult("employee");
  };

  return (
    <header className="topbar no-print">
      <div className="topbar-title">
        <h1 title={companyName}>{companyName}</h1>
        <p>
          Welcome back, <strong>{currentUser}</strong>
        </p>
      </div>

      <div className="topbar-actions">
        <div className="topbar-search" ref={searchRef}>
          <SearchIcon size={16} />
          <input
            ref={searchInputRef}
            type="search"
            aria-label="Search employees"
            placeholder="Search employees, IDs, departments…"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setSearchOpen(true); }}
            onFocus={() => setSearchOpen(true)}
          />
          {searchOpen && query.trim() && (
            <div className="dropdown search-results" role="listbox">
              {results.length === 0 ? (
                <div className="dropdown-empty">No matching employees</div>
              ) : (
                results.map((e) => (
                  <button key={e.id} type="button" className="search-result" onClick={pick}>
                    <span className="pd-avatar">{initials(e.name)}</span>
                    <span className="search-result-text">
                      <strong>{e.name}</strong>
                      <small>{e.id} · {e.department}</small>
                    </span>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        <div className="bell-menu" ref={bellRef}>
          <button
            type="button"
            className="icon-toggle"
            onClick={() => setBellOpen((v) => !v)}
            aria-label={`Notifications${alerts.length ? ` (${alerts.length})` : ""}`}
            aria-expanded={bellOpen}
            title="Notifications"
          >
            <BellIcon />
            {alerts.length > 0 && <span className="bell-dot">{alerts.length > 9 ? "9+" : alerts.length}</span>}
          </button>
          {bellOpen && (
            <div className="dropdown bell-dropdown">
              <div className="bell-head">Notifications</div>
              {alerts.length === 0 ? (
                <div className="dropdown-empty">You're all caught up.</div>
              ) : (
                alerts.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    className="bell-item"
                    onClick={() => { setBellOpen(false); onSelectResult && onSelectResult(a.tab); }}
                  >
                    <i className={`bell-tone tone-${a.tone || "blue"}`} />
                    <span>
                      <strong>{a.title}</strong>
                      <small>{a.detail}</small>
                    </span>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        <div className="profile-menu" ref={menuRef}>
          <button type="button" className="profile-trigger" onClick={() => setMenuOpen((v) => !v)} aria-expanded={menuOpen}>
            <span className="pd-avatar">{isLoggedIn ? initials(currentUser) : "G"}</span>
            <span className="profile-name">{currentUser}</span>
            <ChevronDown />
          </button>
          {menuOpen && (
            <div className="dropdown profile-dropdown">
              {isLoggedIn ? (
                <>
                  <button type="button" onClick={() => { setMenuOpen(false); onSelectResult && onSelectResult("settings"); }}>
                    Profile &amp; Settings
                  </button>
                  <button type="button" className="is-danger" onClick={() => { setMenuOpen(false); onLogout && onLogout(); }}>
                    Sign out
                  </button>
                </>
              ) : (
                <button type="button" onClick={() => { setMenuOpen(false); onLogin && onLogin(); }}>
                  Sign in
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
