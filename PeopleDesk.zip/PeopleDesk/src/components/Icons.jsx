import React from "react";

const base = (size, color) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: color,
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
});

export const SearchIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
);
export const EyeIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
);
export const EditIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
);
export const TrashIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
);
export const CloseIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
);
export const DownloadIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" /></svg>
);
export const PrintIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><polyline points="6 9 6 2 18 2 18 9" /><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></svg>
);
export const PlusIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
);
export const ClockInIcon = ({ size = 14, color = "currentColor" }) => (
  <svg {...base(size, color)}><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
);
export const CheckIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><polyline points="20 6 9 17 4 12" /></svg>
);
export const ChevronLeft = ({ size = 14, color = "currentColor" }) => (
  <svg {...base(size, color)}><polyline points="15 18 9 12 15 6" /></svg>
);
export const ChevronRight = ({ size = 14, color = "currentColor" }) => (
  <svg {...base(size, color)}><polyline points="9 18 15 12 9 6" /></svg>
);
export const InfoIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" /></svg>
);

export const CalendarIcon = ({ size = 16, color = "currentColor" }) => (
  <svg {...base(size, color)}><rect x="3" y="4" width="18" height="18" rx="2" ry="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>
);
