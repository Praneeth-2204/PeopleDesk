import React from "react";
import Button from "./Button";

export default function LeaveForm({
  formData,
  handleChange,
  handleSubmit,
  editingLeaveId,
  employees = [],
  errorMessage,
  onClose
}) {
  return (
    <div className="modal-backdrop">
      <div className="modal-content-box">
        <h3>{editingLeaveId !== null ? "Edit Leave Request" : "Apply"}</h3>

        {errorMessage && <div className="modal-error-alert">{errorMessage}</div>}

        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Employee</label>
            <select
              name="id"
              value={formData.id}
              onChange={handleChange}
              required
            >
              <option value="">Select Employee</option>
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.id} - {emp.name}
                </option>
              ))}
            </select>
          </div>

          <div className="input-group">
            <label>Leave Type</label>
            <select
              name="type"
              value={formData.type}
              onChange={handleChange}
              required
            >
              <option value="Sick Leave">Sick Leave</option>
              <option value="Casual Leave">Casual Leave</option>
              <option value="Paid Leave">Paid Leave</option>
              <option value="Maternity Leave">Maternity Leave</option>
              <option value="Unpaid Leave">Unpaid Leave</option>
            </select>
          </div>

          <div className="input-row-2">
            <div className="input-group">
              <label>From Date</label>
              <input
                type="date"
                name="from"
                value={formData.from}
                onChange={handleChange}
                required
              />
            </div>
            <div className="input-group">
              <label>To Date</label>
              <input
                type="date"
                name="to"
                value={formData.to}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label style={{ color: "#000000", fontWeight: 600 }}>Reason</label>
            <textarea
              name="reason"
              value={formData.reason}
              onChange={handleChange}
              rows="3"
              required
              style={{
                width: "100%",
                padding: "8px 12px",
                borderRadius: "6px",
                border: "1px solid #cbd5e1",
                backgroundColor: "#ffffff",
                color: "#000000",
                fontSize: "14px",
                fontFamily: "inherit",
                boxSizing: "border-box",
                outline: "none"
              }}
            />
          </div>

          {editingLeaveId !== null && (
            <div className="input-group">
              <label>Status</label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                required
              >
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          )}

          <div className="modal-btn-row">
            <Button
              type="submit"
              className={`submit-action-btn ${editingLeaveId !== null ? "update-theme" : "add-theme"}`}
            >
              {editingLeaveId !== null ? "Update Request" : "Apply"}
            </Button>
            <Button type="button" className="cancel-action-btn" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}