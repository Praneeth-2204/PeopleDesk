import React, { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { createPortal } from "react-dom";
import {
  SearchIcon, EyeIcon, EditIcon, TrashIcon, CloseIcon, PlusIcon, CheckIcon, InfoIcon,
  PrintIcon, ChevronLeft, ChevronRight,
} from "./Icons";
import SummaryBoxes from "./SummaryBoxes";
import ViewToggle, { useStoredView } from "./ViewToggle";
import {
  formatDate, formatDateRange, daysBetween, normalizeLeave, initials, todayISO, printView, getCompanyName,
} from "../utils/helpers";

const LEAVE_TYPES = ["Annual Leave", "Sick Leave", "Casual Leave", "Paid Leave", "Maternity Leave", "Paternity Leave", "Bereavement Leave"];
const STATUSES = ["Approved", "Pending", "Rejected"];

/* Reason cell: a single (i) symbol; hovering or focusing it shows the reason in a floating card.
   Long text never takes over the screen: the card has a maximum height and scrolls, it stays open
   while the pointer is on it, and it opens above the symbol when there is no room below. */
function ReasonCell({ text }) {
  const [tip, setTip] = useState(null);
  const timer = useRef(null);
  const reason = (text || "").trim();
  if (!reason) return <span className="pd-reason-empty">—</span>;

  const cancelHide = () => { if (timer.current) { clearTimeout(timer.current); timer.current = null; } };
  const hideSoon = () => { cancelHide(); timer.current = setTimeout(() => setTip(null), 160); };

  const show = (e) => {
    cancelHide();
    const r = e.currentTarget.getBoundingClientRect();
    const width = Math.min(320, window.innerWidth - 24);
    const maxH = 220;
    const left = Math.max(12, Math.min(r.left - 8, window.innerWidth - width - 12));
    const below = window.innerHeight - r.bottom;
    const placeAbove = below < 160 && r.top > below;
    setTip(placeAbove
      ? { left, width, bottom: window.innerHeight - r.top + 8, maxH: Math.min(maxH, r.top - 20) }
      : { left, width, top: r.bottom + 8, maxH: Math.min(maxH, Math.max(120, below - 20)) });
  };

  return (
    <>
      <button
        type="button"
        className="pd-reason-btn"
        aria-label="Show reason for leave"
        onMouseEnter={show}
        onMouseLeave={hideSoon}
        onFocus={show}
        onBlur={hideSoon}
      >
        <InfoIcon size={16} />
      </button>
      {tip && createPortal(
        <div
          className="pd-reason-tip"
          role="tooltip"
          style={{ left: tip.left, width: tip.width, top: tip.top, bottom: tip.bottom, maxHeight: tip.maxH }}
          onMouseEnter={cancelHide}
          onMouseLeave={hideSoon}
        >
          <strong>Reason for leave</strong>
          <p>{reason}</p>
        </div>,
        document.body
      )}
    </>
  );
}

const emptyRequest = { empId: "", leaveType: "Casual Leave", startDate: "", endDate: "", reason: "" };

export default function LeaveModule({ leaveData: propLeaveData, setLeaveData: propSetLeaveData, employees = [], attendanceData = [] }) {
  const [view, setView] = useStoredView("peopledesk_view_leave");
  const [localLeave, setLocalLeave] = useState([]);
  const leaveData = propLeaveData || localLeave;
  const setLeaveData = propSetLeaveData || setLocalLeave;

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newRequest, setNewRequest] = useState(emptyRequest);
  const [formError, setFormError] = useState("");
  const [toast, setToast] = useState("");

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2200);
  }, []);

  /* Older data uses { id, type, from, to } and has no names: upgrade it once. */
  useEffect(() => {
    const needsFix = leaveData.some((r) => !r.empId || !r.leaveId || !r.startDate);
    if (needsFix) setLeaveData((prev) => prev.map((r) => normalizeLeave(r, employees)));
  }, [leaveData, employees, setLeaveData]);

  const rows = useMemo(() => leaveData.map((r) => normalizeLeave(r, employees)), [leaveData, employees]);
  const empInfo = (empId) => employees.find((e) => e.id === empId) || {};

  const patchLeave = (leaveId, patch) =>
    setLeaveData((prev) =>
      prev.map((r) => {
        const n = normalizeLeave(r, employees);
        return n.leaveId === leaveId ? { ...n, ...patch } : r;
      })
    );

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return rows.filter((r) => {
      const matchesSearch =
        !q ||
        r.empName.toLowerCase().includes(q) ||
        r.empId.toLowerCase().includes(q) ||
        r.department.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "All" || r.status === statusFilter;
      /* A request matches when it overlaps the chosen From / To range */
      const matchesFrom = !fromDate || r.endDate >= fromDate;
      const matchesTo = !toDate || r.startDate <= toDate;
      return matchesSearch && matchesStatus && matchesFrom && matchesTo;
    });
  }, [rows, searchQuery, statusFilter, fromDate, toDate]);

  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / rowsPerPage));
  const page = Math.min(currentPage, totalPages);
  const startIdx = total === 0 ? 0 : (page - 1) * rowsPerPage + 1;
  const endIdx = Math.min(page * rowsPerPage, total);
  const pageRows = filtered.slice((page - 1) * rowsPerPage, page * rowsPerPage);

  const count = (s) => rows.filter((r) => r.status === s).length;
  const resetPage = (setter) => (e) => { setter(e.target.value); setCurrentPage(1); };

  const closeAdd = () => { setIsAddOpen(false); setFormError(""); setNewRequest(emptyRequest); };

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { setIsAddOpen(false); setEditing(null); setViewing(null); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const submitNew = (e) => {
    e.preventDefault();
    if (!newRequest.empId || !newRequest.startDate || !newRequest.endDate) {
      setFormError("Employee, start date and end date are required.");
      return;
    }
    if (new Date(newRequest.endDate) < new Date(newRequest.startDate)) {
      setFormError("End date cannot be earlier than start date.");
      return;
    }
    const clash = rows.find(
      (r) =>
        r.empId === newRequest.empId &&
        r.status !== "Rejected" &&
        r.startDate <= newRequest.endDate &&
        r.endDate >= newRequest.startDate
    );
    if (clash) {
      setFormError(`This employee already has a ${clash.status.toLowerCase()} leave from ${formatDate(clash.startDate)} to ${formatDate(clash.endDate)}.`);
      return;
    }
    const emp = empInfo(newRequest.empId);
    setLeaveData((prev) => [
      ...prev,
      {
        leaveId: `LV-${Date.now().toString().slice(-6)}`,
        empId: newRequest.empId,
        empName: emp.name || "",
        department: emp.department || "",
        leaveType: newRequest.leaveType,
        startDate: newRequest.startDate,
        endDate: newRequest.endDate,
        reason: newRequest.reason,
        status: "Pending",
      },
    ]);
    closeAdd();
    showToast("Leave request submitted");
  };

  const renderActions = (r) => (
    <div className="pd-actions">
      {r.status === "Pending" && (
        <>
          <button type="button" className="pd-icon-btn is-success" title="Approve" onClick={() => { patchLeave(r.leaveId, { status: "Approved" }); showToast(`Approved ${r.empName}'s request`); }}><CheckIcon size={14} /></button>
          <button type="button" className="pd-icon-btn is-danger" title="Reject" onClick={() => { patchLeave(r.leaveId, { status: "Rejected" }); showToast(`Rejected ${r.empName}'s request`); }}><CloseIcon size={14} /></button>
        </>
      )}
      <button type="button" className="pd-icon-btn" title="View details" onClick={() => setViewing(r)}><EyeIcon size={14} /></button>
      <button type="button" className="pd-icon-btn" title="Edit request" onClick={() => setEditing({ ...r })}><EditIcon size={14} /></button>
      <button type="button" className="pd-icon-btn is-danger" title="Delete request"
        onClick={() => {
          if (!window.confirm("Delete this leave request?")) return;
          setLeaveData((prev) => prev.filter((x) => normalizeLeave(x, employees).leaveId !== r.leaveId));
          showToast("Leave request deleted");
        }}><TrashIcon size={14} /></button>
    </div>
  );

  const viewEmp = viewing ? empInfo(viewing.empId) : {};
  const empLeaves = viewing ? rows.filter((r) => r.empId === viewing.empId) : [];

  return (
    <div className="pd-page fit">
      <div className="pd-page-head no-print">
        <div>
          <h2 className="pd-title">Leave Management</h2>
          <p className="pd-sub">Track employee leave requests, approvals and leave history.</p>
        </div>
        <div className="pd-head-actions">
          <button type="button" className="pd-btn pd-btn-primary" onClick={() => setIsAddOpen(true)}>
            <PlusIcon /> New Leave Request
          </button>
        </div>
      </div>

      {/* Filters: leave-type dropdown removed, From / To dates sit side by side */}
      <div className="pd-toolbar no-print">
        <div className="pd-search">
          <SearchIcon size={15} />
          <input type="search" className="pd-input" placeholder="Search by name, ID, department…" value={searchQuery} onChange={resetPage(setSearchQuery)} />
        </div>
        <select className="pd-select" value={statusFilter} onChange={resetPage(setStatusFilter)}>
          <option value="All">All Statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <div className="pd-date-range">
          <label>From<input type="date" className="pd-input pd-date" value={fromDate} onChange={resetPage(setFromDate)} /></label>
          <label>To<input type="date" className="pd-input pd-date" value={toDate} min={fromDate || undefined} onChange={resetPage(setToDate)} /></label>
        </div>
        {(searchQuery || statusFilter !== "All" || fromDate || toDate) && (
          <button type="button" className="pd-btn pd-btn-ghost" onClick={() => { setSearchQuery(""); setStatusFilter("All"); setFromDate(""); setToDate(""); setCurrentPage(1); }}>
            Clear filters
          </button>
        )}
        <ViewToggle value={view} onChange={setView} />
      </div>

      <SummaryBoxes employees={employees} todayRows={attendanceData} />

      <div className="pd-card pd-table-card">
        {view === "cards" ? (
          <div className="pd-cards-wrap">
            {pageRows.length === 0 ? (
              <div className="pd-empty">No leave requests match the current filters.</div>
            ) : (
              <div className="pd-card-grid">
                {pageRows.map((r) => (
                  <article className="pd-person-card" key={r.leaveId}>
                    <div className="pd-person-top">
                      <span className="pd-avatar">{initials(r.empName)}</span>
                      <div className="pd-user-stack">
                        <span className="pd-user-name">{r.empName || "Unknown employee"}</span>
                        <span className="pd-person-id">{r.empId} · {r.department || "—"}</span>
                      </div>
                      <span className={`pd-badge ${r.status.toLowerCase()}`}>{r.status}</span>
                    </div>
                    <div className="pd-person-meta">
                      <div><span>Leave type</span><strong>{r.leaveType}</strong></div>
                      <div><span>Days</span><strong>{daysBetween(r.startDate, r.endDate)}</strong></div>
                      <div style={{ gridColumn: "span 2" }}><span>Dates</span><strong>{formatDateRange(r.startDate, r.endDate)}</strong></div>
                      {r.reason && <div style={{ gridColumn: "span 2" }}><span>Reason</span><strong className="pd-clamp" title={r.reason}>{r.reason}</strong></div>}
                    </div>
                    <div className="pd-person-foot">{renderActions(r)}</div>
                  </article>
                ))}
              </div>
            )}
          </div>
        ) : (
        <div className="pd-table-wrap">
          <table className="pd-table leave-table">
            <colgroup>
              <col />
              <col style={{ width: "130px" }} />
              <col style={{ width: "120px" }} />
              <col style={{ width: "190px" }} />
              <col style={{ width: "70px" }} />
              <col style={{ width: "80px" }} />
              <col style={{ width: "130px" }} />
              <col style={{ width: "180px" }} />
            </colgroup>
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Leave Type</th>
                <th>Dates</th>
                <th className="th-center">Days</th>
                <th className="th-center">Reason</th>
                <th className="th-center">Status</th>
                <th className="th-center no-print">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.length === 0 ? (
                <tr><td colSpan="8" className="pd-empty">No leave requests match the current filters.</td></tr>
              ) : (
                pageRows.map((r) => {
                  const info = empInfo(r.empId);
                  return (
                    <tr key={r.leaveId}>
                      <td>
                        <div className="pd-user">
                          <span className="pd-avatar">{initials(r.empName)}</span>
                          <div className="pd-user-stack">
                            <span className="pd-user-name">{r.empName || "Unknown employee"}</span>
                            <span className="pd-user-meta" title={info.designation || ""}>{r.empId}</span>
                          </div>
                        </div>
                      </td>
                      <td>{r.department || "—"}</td>
                      <td>{r.leaveType}</td>
                      <td className="pd-nowrap">{formatDateRange(r.startDate, r.endDate)}</td>
                      <td className="pd-mono td-center">{daysBetween(r.startDate, r.endDate)}</td>
                      <td className="pd-reason-col td-center"><ReasonCell text={r.reason} /></td>
                      <td className="td-center"><span className={`pd-badge ${r.status.toLowerCase()}`}>{r.status}</span></td>
                      <td className="no-print td-center">
                        {renderActions(r)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        )}

        <div className="pd-footer no-print">
          <div className="pd-showing">
            <span>Showing {startIdx} – {endIdx} of {total} requests</span>
            <span>Approved {count("Approved")} · Pending {count("Pending")} · Rejected {count("Rejected")}</span>
            <label className="pd-rows">
              Rows
              <select className="pd-select pd-select-sm" value={rowsPerPage} onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}>
                {[5, 10, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>
          <div className="pd-pager">
            <button type="button" className="pd-pager-btn" disabled={page === 1} onClick={() => setCurrentPage(page - 1)}><ChevronLeft /> Previous</button>
            <span className="pd-pager-info">{page} / {totalPages}</span>
            <button type="button" className="pd-pager-btn" disabled={page === totalPages} onClick={() => setCurrentPage(page + 1)}>Next <ChevronRight /></button>
          </div>
        </div>
      </div>

      {/* ---------- New request ---------- */}
      {isAddOpen && (
        <div className="pd-modal-backdrop no-print" onMouseDown={(e) => e.target === e.currentTarget && closeAdd()}>
          <form className="pd-modal" onSubmit={submitNew}>
            <div className="pd-modal-head">
              <div><h3>New leave request</h3><p>Choose an employee and the dates of leave.</p></div>
              <button type="button" className="pd-icon-btn" onClick={closeAdd} aria-label="Close"><CloseIcon /></button>
            </div>
            <div className="pd-modal-body pd-form-grid">
              {formError && <div className="pd-alert pd-span-2">{formError}</div>}
              <label className="pd-field pd-span-2">
                <span>Employee *</span>
                <select className="pd-select" value={newRequest.empId} onChange={(e) => setNewRequest({ ...newRequest, empId: e.target.value })}>
                  <option value="">Select employee…</option>
                  {employees.map((e) => <option key={e.id} value={e.id}>{e.name} ({e.id}) · {e.department}</option>)}
                </select>
              </label>
              <label className="pd-field pd-span-2">
                <span>Leave type</span>
                <select className="pd-select" value={newRequest.leaveType} onChange={(e) => setNewRequest({ ...newRequest, leaveType: e.target.value })}>
                  {LEAVE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="pd-field">
                <span>Start date *</span>
                <input type="date" className="pd-input" value={newRequest.startDate} onChange={(e) => setNewRequest({ ...newRequest, startDate: e.target.value })} />
              </label>
              <label className="pd-field">
                <span>End date *</span>
                <input type="date" className="pd-input" min={newRequest.startDate || undefined} value={newRequest.endDate} onChange={(e) => setNewRequest({ ...newRequest, endDate: e.target.value })} />
              </label>
              <label className="pd-field pd-span-2">
                <span>Reason</span>
                <textarea className="pd-input pd-textarea" rows="3" value={newRequest.reason} onChange={(e) => setNewRequest({ ...newRequest, reason: e.target.value })} placeholder="Optional" />
              </label>
              {newRequest.startDate && newRequest.endDate && (
                <div className="pd-note pd-span-2">Duration: {daysBetween(newRequest.startDate, newRequest.endDate)}</div>
              )}
            </div>
            <div className="pd-modal-foot">
              <button type="button" className="pd-btn" onClick={closeAdd}>Cancel</button>
              <button type="submit" className="pd-btn pd-btn-primary">Submit request</button>
            </div>
          </form>
        </div>
      )}

      {/* ---------- Edit ---------- */}
      {editing && (
        <div className="pd-modal-backdrop no-print" onMouseDown={(e) => e.target === e.currentTarget && setEditing(null)}>
          <form
            className="pd-modal"
            onSubmit={(e) => {
              e.preventDefault();
              if (new Date(editing.endDate) < new Date(editing.startDate)) { showToast("End date cannot be before start date"); return; }
              patchLeave(editing.leaveId, {
                leaveType: editing.leaveType, startDate: editing.startDate, endDate: editing.endDate,
                reason: editing.reason, status: editing.status,
              });
              setEditing(null);
              showToast("Leave request updated");
            }}
          >
            <div className="pd-modal-head">
              <div><h3>Edit leave request</h3><p>{editing.empName} · {editing.empId}</p></div>
              <button type="button" className="pd-icon-btn" onClick={() => setEditing(null)} aria-label="Close"><CloseIcon /></button>
            </div>
            <div className="pd-modal-body pd-form-grid">
              <label className="pd-field">
                <span>Leave type</span>
                <select className="pd-select" value={editing.leaveType} onChange={(e) => setEditing({ ...editing, leaveType: e.target.value })}>
                  {[...new Set([...LEAVE_TYPES, editing.leaveType])].map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="pd-field">
                <span>Status</span>
                <select className="pd-select" value={editing.status} onChange={(e) => setEditing({ ...editing, status: e.target.value })}>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </label>
              <label className="pd-field">
                <span>Start date</span>
                <input type="date" className="pd-input" value={editing.startDate} onChange={(e) => setEditing({ ...editing, startDate: e.target.value })} />
              </label>
              <label className="pd-field">
                <span>End date</span>
                <input type="date" className="pd-input" value={editing.endDate} onChange={(e) => setEditing({ ...editing, endDate: e.target.value })} />
              </label>
              <label className="pd-field pd-span-2">
                <span>Reason</span>
                <textarea className="pd-input pd-textarea" rows="3" value={editing.reason} onChange={(e) => setEditing({ ...editing, reason: e.target.value })} />
              </label>
            </div>
            <div className="pd-modal-foot">
              <button type="button" className="pd-btn" onClick={() => setEditing(null)}>Cancel</button>
              <button type="submit" className="pd-btn pd-btn-primary">Save changes</button>
            </div>
          </form>
        </div>
      )}

      {/* ---------- View details (employee information) ---------- */}
      {viewing && (
        <div className="pd-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setViewing(null)}>
          <div className="pd-modal print-area">
            <div className="print-only pd-print-title"><h2>{getCompanyName()} · Leave request</h2></div>
            <div className="pd-modal-head">
              <div className="pd-user">
                <span className="pd-avatar pd-avatar-lg">{initials(viewing.empName)}</span>
                <div>
                  <h3>{viewing.empName || "Unknown employee"}</h3>
                  <p>{viewEmp.designation || "Employee"} · {viewing.department || "—"}</p>
                </div>
              </div>
              <button type="button" className="pd-icon-btn no-print" onClick={() => setViewing(null)} aria-label="Close"><CloseIcon /></button>
            </div>
            <div className="pd-modal-body">
              <h4 className="pd-section-title">Employee information</h4>
              <div className="pd-detail-grid">
                <div><span>Employee ID</span><strong>{viewing.empId}</strong></div>
                <div><span>Employment status</span><strong>{viewEmp.status || "—"}</strong></div>
                <div><span>Email</span><strong>{viewEmp.email || "—"}</strong></div>
                <div><span>Joined</span><strong>{viewEmp.joined ? formatDate(viewEmp.joined) : "—"}</strong></div>
              </div>
              <h4 className="pd-section-title">Leave details</h4>
              <div className="pd-detail-grid">
                <div><span>Leave type</span><strong>{viewing.leaveType}</strong></div>
                <div><span>Status</span><strong><span className={`pd-badge ${viewing.status.toLowerCase()}`}>{viewing.status}</span></strong></div>
                <div><span>Start date</span><strong>{formatDate(viewing.startDate)}</strong></div>
                <div><span>End date</span><strong>{formatDate(viewing.endDate)}</strong></div>
                <div><span>Days</span><strong>{daysBetween(viewing.startDate, viewing.endDate)}</strong></div>
                <div><span>Requests by employee</span><strong>{empLeaves.length}</strong></div>
                <div className="pd-span-2"><span>Reason</span><p className="pd-reason-box">{viewing.reason || "No reason provided"}</p></div>
              </div>
            </div>
            <div className="pd-modal-foot no-print">
              {viewing.status === "Pending" && (
                <>
                  <button type="button" className="pd-btn pd-btn-danger" onClick={() => { patchLeave(viewing.leaveId, { status: "Rejected" }); setViewing(null); showToast("Request rejected"); }}>Reject</button>
                  <button type="button" className="pd-btn pd-btn-primary" onClick={() => { patchLeave(viewing.leaveId, { status: "Approved" }); setViewing(null); showToast("Request approved"); }}>Approve</button>
                </>
              )}
              <button type="button" className="pd-btn" onClick={() => setViewing(null)}>Close</button>
              <button type="button" className="pd-btn pd-btn-action" onClick={printView}><PrintIcon /> Print</button>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="pd-toast no-print" role="status">{toast}</div>}
    </div>
  );
}
