import React, { useMemo, useState } from "react";
import { DownloadIcon, PrintIcon } from "./Icons";
import {
  todayISO, formatDate, normalizeAttendance, normalizeLeave, daysBetween,
  initials, downloadCSV, getCompanyName,
} from "../utils/helpers";

const PALETTE = ["#4f46e5", "#0d9488", "#7c3aed", "#C77700", "#1e1b4b", "#3D8BDB", "#B83280", "#7A8CA5"];
const pct = (n, d) => (d ? (n / d) * 100 : 0);

export default function ReportsModule({ employees = [], attendanceData = [], leaveData = [] }) {
  const [activeTab, setActiveTab] = useState("charts");
  const [scope, setScope] = useState("All");

  const departments = useMemo(
    () => Array.from(new Set(employees.map((e) => e.department).filter(Boolean))).sort(),
    [employees]
  );

  /* Everything below is filtered by the chosen scope (whole company or one department) */
  const scopedEmployees = useMemo(
    () => (scope === "All" ? employees : employees.filter((e) => e.department === scope)),
    [employees, scope]
  );
  const ids = useMemo(() => new Set(scopedEmployees.map((e) => e.id)), [scopedEmployees]);

  const attendance = useMemo(
    () => attendanceData.map((a) => normalizeAttendance(a)).filter((a) => ids.has(a.empId)),
    [attendanceData, ids]
  );
  const leaves = useMemo(
    () => leaveData.map((l) => normalizeLeave(l, employees)).filter((l) => ids.has(l.empId)),
    [leaveData, employees, ids]
  );

  const headcount = scopedEmployees.length;
  const att = (s) => attendance.filter((a) => a.status === s).length;
  const present = att("Present");
  const late = att("Late");
  const absent = att("Absent");
  const onLeave = att("On Leave");
  const attendanceRate = pct(present + late, headcount);
  const approved = leaves.filter((l) => l.status === "Approved").length;
  const pending = leaves.filter((l) => l.status === "Pending").length;
  const rejected = leaves.filter((l) => l.status === "Rejected").length;

  const deptRows = useMemo(() => {
    const list = Array.from(new Set(scopedEmployees.map((e) => e.department).filter(Boolean))).sort();
    return list.map((d, i) => {
      const emps = scopedEmployees.filter((e) => e.department === d);
      const empIds = new Set(emps.map((e) => e.id));
      const a = attendance.filter((x) => empIds.has(x.empId));
      const l = leaves.filter((x) => empIds.has(x.empId));
      return {
        name: d,
        color: PALETTE[i % PALETTE.length],
        staff: emps.length,
        share: pct(emps.length, headcount),
        present: a.filter((x) => x.status === "Present" || x.status === "Late").length,
        absent: a.filter((x) => x.status === "Absent").length,
        onLeave: a.filter((x) => x.status === "On Leave").length,
        leaves: l.length,
      };
    }).sort((x, y) => y.staff - x.staff);
  }, [scopedEmployees, attendance, leaves, headcount]);

  const leaveByType = useMemo(() => {
    const map = {};
    leaves.forEach((l) => { map[l.leaveType] = (map[l.leaveType] || 0) + daysBetween(l.startDate, l.endDate); });
    return Object.entries(map).map(([type, days]) => ({ type, days })).sort((a, b) => b.days - a.days);
  }, [leaves]);

  const roster = useMemo(
    () => scopedEmployees.map((e) => {
      const a = attendance.find((x) => x.empId === e.id);
      return { ...e, today: a ? a.status : "—" };
    }),
    [scopedEmployees, attendance]
  );

  const scopeLabel = scope === "All" ? "Enterprise-wide" : `${scope} department`;

  /* ---------- Actions (these were not wired before) ---------- */
  const handlePrint = () => window.print();

  const handleExport = () => {
    downloadCSV(`workforce_report_${todayISO()}.csv`, [
      [`${getCompanyName()} workforce report`],
      ["Scope", scopeLabel],
      ["Generated", formatDate(todayISO())],
      [],
      ["Summary"],
      ["Total headcount", headcount],
      ["Present", present], ["Late", late], ["Absent", absent], ["On leave", onLeave],
      ["Attendance rate", `${attendanceRate.toFixed(1)}%`],
      ["Leave requests approved", approved], ["Leave requests pending", pending], ["Leave requests rejected", rejected],
      [],
      ["Department matrix"],
      ["Department", "Employees", "Share", "Present/Late", "Absent", "On leave", "Leave requests"],
      ...deptRows.map((d) => [d.name, d.staff, `${d.share.toFixed(1)}%`, d.present, d.absent, d.onLeave, d.leaves]),
      [],
      ["Workforce roster"],
      ["Employee ID", "Name", "Department", "Designation", "Email", "Joined", "Employment status", "Today"],
      ...roster.map((e) => [e.id, e.name, e.department, e.designation, e.email, e.joined, e.status, e.today]),
    ]);
  };

  /* ---------- Donut for leave status ---------- */
  const donut = [
    { label: "Approved", value: approved, color: "#17803D" },
    { label: "Pending", value: pending, color: "#C77700" },
    { label: "Rejected", value: rejected, color: "#C0392B" },
  ];
  const donutTotal = approved + pending + rejected;
  const R = 50;
  const C = 2 * Math.PI * R;
  let offset = 0;

  const kpis = [
    { label: "Total headcount", value: headcount, sub: scopeLabel, tone: "is-blue" },
    { label: "Attendance rate", value: `${attendanceRate.toFixed(1)}%`, sub: `${present + late} of ${headcount} checked in`, tone: "is-green" },
    { label: "Leave requests", value: leaves.length, sub: `${approved} approved · ${pending} pending`, tone: "is-amber" },
    { label: "Absent today", value: absent, sub: `${pct(absent, headcount).toFixed(1)}% of workforce`, tone: "is-red" },
  ];

  const maxStaff = Math.max(...deptRows.map((d) => d.staff), 1);
  const maxDays = Math.max(...leaveByType.map((t) => t.days), 1);

  return (
    <div className="pd-page reports-page">
      <div className="pd-print-title">
        <h2>{getCompanyName()} — Workforce Report</h2>
        <p>{scopeLabel} · Generated {formatDate(todayISO())}</p>
      </div>

      <div className="pd-page-head no-print">
        <div>
          <h2 className="pd-title">Reports &amp; Analytics</h2>
          <p className="pd-sub">Workforce allocation, attendance and leave activity for {scopeLabel.toLowerCase()}.</p>
        </div>
        <div className="pd-head-actions">
          <select className="pd-select" value={scope} onChange={(e) => setScope(e.target.value)} aria-label="Report scope">
            <option value="All">Scope: Enterprise-wide</option>
            {departments.map((d) => <option key={d} value={d}>Scope: {d}</option>)}
          </select>
          <button type="button" className="pd-btn pd-btn-action" onClick={handlePrint}><PrintIcon /> Print report</button>
          <button type="button" className="pd-btn pd-btn-action" onClick={handleExport}><DownloadIcon /> Export CSV</button>
        </div>
      </div>

      <div className="pd-stats pd-stats-4">
        {kpis.map((k) => (
          <div key={k.label} className={`pd-stat ${k.tone}`}>
            <span>{k.label}</span>
            <strong>{k.value}</strong>
            <em>{k.sub}</em>
          </div>
        ))}
      </div>

      <div className="pd-tabs no-print" role="tablist">
        {[
          ["charts", "Executive summary"],
          ["matrix", "Department matrix"],
          ["roster", "Workforce roster"],
        ].map(([key, label]) => (
          <button key={key} type="button" role="tab" aria-selected={activeTab === key} className={`pd-tab ${activeTab === key ? "active" : ""}`} onClick={() => setActiveTab(key)}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "charts" && (
        <div className="pd-grid-2">
          <div className="pd-card pd-panel">
            <h3>Workforce by department</h3>
            <p className="pd-panel-sub">{deptRows.length} departments · {headcount} employees</p>
            {deptRows.length === 0 && <div className="pd-empty">No employees in this scope.</div>}
            {deptRows.map((d) => (
              <div key={d.name} className="pd-bar-row">
                <span className="pd-bar-label">{d.name}</span>
                <div className="pd-bar-track"><div className="pd-bar-fill" style={{ width: `${(d.staff / maxStaff) * 100}%`, background: d.color }} /></div>
                <span className="pd-bar-value">{d.staff} <small>({d.share.toFixed(1)}%)</small></span>
              </div>
            ))}
          </div>

          <div className="pd-card pd-panel">
            <h3>Today's attendance</h3>
            <p className="pd-panel-sub">Check-in status across the selected scope</p>
            <div className="pd-columns">
              {[
                ["Present", present, "#17803D"],
                ["Late", late, "#C77700"],
                ["Absent", absent, "#C0392B"],
                ["On leave", onLeave, "#7c3aed"],
              ].map(([label, value, color]) => (
                <div key={label} className="pd-column">
                  <strong style={{ color }}>{value}</strong>
                  <div className="pd-column-bar" style={{ height: `${Math.max(pct(value, headcount) * 1.6, 4)}px`, background: color }} />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pd-card pd-panel">
            <h3>Leave requests by status</h3>
            <p className="pd-panel-sub">Distribution of all requests</p>
            <div className="pd-donut-row">
              <div className="pd-donut">
                <svg viewBox="0 0 120 120" role="img" aria-label="Leave status chart">
                  <circle cx="60" cy="60" r={R} fill="none" stroke="var(--pd-line-soft)" strokeWidth="10" />
                  {donutTotal > 0 && donut.map((s) => {
                    const len = (s.value / donutTotal) * C;
                    const el = (
                      <circle key={s.label} cx="60" cy="60" r={R} fill="none" stroke={s.color} strokeWidth="10"
                        strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} transform="rotate(-90 60 60)" />
                    );
                    offset += len;
                    return el;
                  })}
                </svg>
                <div className="pd-donut-center"><strong>{donutTotal}</strong><span>Requests</span></div>
              </div>
              <ul className="pd-legend">
                {donut.map((s) => (
                  <li key={s.label}>
                    <i style={{ background: s.color }} />
                    <span>{s.label}</span>
                    <b>{s.value} <small>({pct(s.value, donutTotal).toFixed(1)}%)</small></b>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pd-card pd-panel">
            <h3>Leave days by type</h3>
            <p className="pd-panel-sub">Total number of days requested per leave type</p>
            {leaveByType.length === 0 && <div className="pd-empty">No leave requests in this scope.</div>}
            {leaveByType.map((t, i) => (
              <div key={t.type} className="pd-bar-row">
                <span className="pd-bar-label">{t.type}</span>
                <div className="pd-bar-track"><div className="pd-bar-fill" style={{ width: `${(t.days / maxDays) * 100}%`, background: PALETTE[i % PALETTE.length] }} /></div>
                <span className="pd-bar-value">{t.days}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "matrix" && (
        <div className="pd-card pd-table-card">
          <div className="pd-table-wrap">
            <table className="pd-table">
              <thead>
                <tr><th>Department</th><th>Employees</th><th>Share</th><th>Present / Late</th><th>Absent</th><th>On leave</th><th>Leave requests</th></tr>
              </thead>
              <tbody>
                {deptRows.length === 0 ? (
                  <tr><td colSpan="7" className="pd-empty">No data for this scope.</td></tr>
                ) : deptRows.map((d) => (
                  <tr key={d.name}>
                    <td><span className="pd-dot" style={{ background: d.color }} />{d.name}</td>
                    <td>{d.staff}</td>
                    <td>{d.share.toFixed(1)}%</td>
                    <td>{d.present}</td>
                    <td>{d.absent}</td>
                    <td>{d.onLeave}</td>
                    <td>{d.leaves}</td>
                  </tr>
                ))}
              </tbody>
              {deptRows.length > 0 && (
                <tfoot>
                  <tr>
                    <th>Total</th><th>{headcount}</th><th>100%</th>
                    <th>{present + late}</th><th>{absent}</th><th>{onLeave}</th><th>{leaves.length}</th>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {activeTab === "roster" && (
        <div className="pd-card pd-table-card">
          <div className="pd-table-wrap">
            <table className="pd-table">
              <thead>
                <tr><th>Employee</th><th>Department</th><th>Designation</th><th>Joined</th><th>Employment</th><th>Today</th></tr>
              </thead>
              <tbody>
                {roster.length === 0 ? (
                  <tr><td colSpan="6" className="pd-empty">No employees in this scope.</td></tr>
                ) : roster.map((e) => (
                  <tr key={e.id}>
                    <td>
                      <div className="pd-user">
                        <span className="pd-avatar">{initials(e.name)}</span>
                        <div className="pd-user-stack"><span className="pd-user-name">{e.name}</span><span className="pd-user-meta">{e.id}</span></div>
                      </div>
                    </td>
                    <td>{e.department}</td>
                    <td>{e.designation}</td>
                    <td>{e.joined ? formatDate(e.joined) : "—"}</td>
                    <td>{e.status}</td>
                    <td><span className={`pd-badge ${String(e.today).toLowerCase().replace(/\s+/g, "-")}`}>{e.today}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="pd-footer"><div className="pd-showing"><span>{roster.length} employees in scope</span></div></div>
        </div>
      )}
    </div>
  );
}
