import React, { useState, useEffect, useRef } from "react";
import { DATE_FORMATS, todayISO, initials, formatDate, downloadCSV } from "../utils/helpers";
import { ADMIN } from "../config";
import { PrintIcon, DownloadIcon } from "./Icons";

const MENU = [
  { id: "profile", label: "Profile", hint: "Your personal details" },
  { id: "company", label: "Company preferences", hint: "Name, department, date format" },
  { id: "notifications", label: "Notifications", hint: "What you get alerted about" },
  { id: "account", label: "Account & appearance", hint: "Access and theme" },
  { id: "data", label: "Data & backup", hint: "Export, restore, reset" },
  { id: "activity", label: "Activity log", hint: "Audit trail of changes" },
  { id: "about", label: "About & support", hint: "Help, shortcuts, contact" },
];

/* Appearance modes (shown by name only) */
const THEME_GROUPS = [
  { title: "Light modes", themes: [
    ["light", "Light"], ["ivory", "Ivory"], ["corporate", "Corporate"], ["steel", "Steel Blue"], ["slate", "Slate"],
    ["teal", "Teal Professional"], ["ocean", "Ocean"], ["forest", "Forest"], ["sunset", "Sunset"], ["royal", "Royal"],
    ["executive", "Executive"], ["burgundy", "Burgundy"], ["rose", "Rose Quartz"], ["lavender", "Lavender Mist"],
    ["sapphire", "Sapphire"], ["solarized", "Solarized Light"], ["contrast", "High contrast"],
    ["mint", "Mint Fresh"], ["sky", "Sky Blue"], ["peach", "Peach Cream"], ["sand", "Desert Sand"],
    ["arctic", "Arctic White"], ["honey", "Honey Gold"], ["coral", "Coral Reef"], ["paper", "Paper"],
    ["orchid", "Orchid"], ["jade", "Jade Garden"],
  ] },
  { title: "Dark modes", themes: [
    ["dark", "Dark"], ["midnight", "Midnight"], ["graphite", "Graphite"], ["nord", "Nord"], ["aurora", "Aurora"],
    ["dracula", "Dracula"], ["emerald", "Emerald Night"], ["mocha", "Mocha"], ["cyber", "Cyber Neon"], ["crimson", "Crimson Night"],
  ] },
  { title: "Automatic", themes: [["system", "System (match device)"]] },
];
const THEMES = THEME_GROUPS.flatMap((g) => g.themes.map(([id, label]) => ({ id, label })));

const NOTIFICATION_HINTS = {
  "Attendance reminders": "Bell alert when employees have not checked in today",
  "Leave request updates": "Bell alert for leave requests waiting for approval",
  "Company announcements": "Work anniversaries and who is on leave today",
  "Employee directory updates": "Bell alert with the details whenever an employee is added, edited or removed, and for new joiners",
};

const EMPLOYMENT_TYPES = ["Full Time", "Part Time", "Contract", "Intern", "Temporary"];
const BASE_DEPARTMENTS = ["Engineering", "Design", "Sales", "Finance", "IT", "HR", "Marketing", "Operations"];

function Field({ label, required, children, hint }) {
  return (
    <label className="pd-field">
      <span>{label}{required && " *"}</span>
      {children}
      {hint && <small className="field-hint">{hint}</small>}
    </label>
  );
}

function Toggle({ checked, onChange, label, description }) {
  return (
    <label className="toggle-row">
      <div>
        <strong>{label}</strong>
        {description && <span>{description}</span>}
      </div>
      <input type="checkbox" className="switch" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

export default function SettingsView({
  subTab = "profile",
  setSubTab,
  profile,
  employees = [],
  company,
  notifications,
  onSaveProfile,
  onSaveCompany,
  onSaveNotifications,
  theme = "light",
  setTheme,
  density = "comfortable",
  setDensity,
  accent = "default",
  setAccent,
  accentOptions = [],
  auditLog = [],
  onClearLog,
  onExportBackup,
  onImportBackup,
  onResetDemo,
  counts = { employees: 0, leaves: 0, attendance: 0 },
}) {
  const active = MENU.some((m) => m.id === String(subTab).toLowerCase()) ? String(subTab).toLowerCase() : "profile";

  const [profileDraft, setProfileDraft] = useState(profile);
  const [companyDraft, setCompanyDraft] = useState(company);
  const [notifDraft, setNotifDraft] = useState(notifications);
  const [photo, setPhoto] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState({ text: "", type: "ok" });
  const backupInput = useRef(null);

  /* When the underlying data changes anywhere else in the app, the forms follow. */
  useEffect(() => { setProfileDraft(profile); }, [profile]);
  useEffect(() => { setCompanyDraft(company); }, [company]);
  useEffect(() => { setNotifDraft(notifications); }, [notifications]);

  const say = (text, type = "ok") => setMessage({ text, type });
  const switchTab = (id) => { setSubTab(id); say(""); };

  const departments = Array.from(new Set([...BASE_DEPARTMENTS, company.defaultDepartment, ...employees.map((e) => e.department)])).sort();
  const setP = (k) => (e) => { setProfileDraft({ ...profileDraft, [k]: e.target.value }); say(""); };

  const chooseEmployee = (e) => {
    const emp = employees.find((x) => x.id === e.target.value);
    if (!emp) return;
    setProfileDraft({
      ...profileDraft,
      employeeId: emp.id,
      fullName: emp.name,
      email: emp.email,
      jobRole: emp.designation || "",
      department: emp.department,
      joiningDate: emp.joined || "",
    });
    say("");
  };

  const onPhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png"].includes(file.type)) return say("Please upload a JPG or PNG image.", "error");
    if (file.size > 2 * 1024 * 1024) return say("Image size must be 2 MB or less.", "error");
    const reader = new FileReader();
    reader.onload = () => setPhoto(String(reader.result));
    reader.readAsDataURL(file);
  };

  const submitProfile = (e) => {
    e.preventDefault();
    if (!employees.some((x) => x.id === profileDraft.employeeId)) return say("Pick an employee from the directory.", "error");
    if (!profileDraft.fullName.trim() || !profileDraft.email.trim()) return say("Name and email are required.", "error");
    onSaveProfile(profileDraft);
    say("Profile saved. The change is now reflected in Employees, Attendance, Leave and Reports.");
  };

  const submitCompany = (e) => {
    e.preventDefault();
    if (!companyDraft.name.trim()) return say("Company name is required.", "error");
    onSaveCompany({ ...companyDraft, name: companyDraft.name.trim() });
    say("Company preferences saved and applied across the app.");
  };

  const submitNotifications = (e) => {
    e.preventDefault();
    onSaveNotifications(notifDraft);
    say("Notification preferences saved.");
  };

  const onBackupFile = (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        onImportBackup(String(reader.result));
        say("Backup restored. Employees, attendance, leave and settings were replaced with the file's data.");
      } catch (err) {
        say(err.message || "That file could not be read.", "error");
      }
    };
    reader.readAsText(file);
  };

  const feedback = message.text && (
    <div className={`settings-feedback ${message.type === "error" ? "is-error" : ""}`} role="status">{message.text}</div>
  );

  return (
    <div className="settings-page">
      <div className="pd-page-head no-print">
        <div>
          <h2 className="pd-title">Settings</h2>
          <p className="pd-sub">Changes made here update the whole application.</p>
        </div>
        <div className="pd-head-actions">
          <button type="button" className="pd-btn pd-btn-action" onClick={() => window.print()}>
            <PrintIcon /> Print summary
          </button>
        </div>
      </div>

      <div className="print-only">
        <div className="pd-print-title">
          <h2>{company.name} · Settings summary</h2>
          <p>Printed {formatDate(todayISO())}</p>
        </div>
        <table className="pd-table">
          <tbody>
            {[
              ["Administrator", ADMIN.name],
              ["Administrator email", ADMIN.email],
              ["Company name", company.name],
              ["Default department", company.defaultDepartment],
              ["Date format", company.dateFormat],
              ["Appearance mode", (THEMES.find((t) => t.id === theme) || {}).label || theme],
              ["Employees", counts.employees],
              ["Leave requests", counts.leaves],
              ["Attendance records", counts.attendance],
            ].map(([k, v]) => <tr key={k}><td><strong>{k}</strong></td><td>{v}</td></tr>)}
          </tbody>
        </table>
      </div>

      <div className="settings-layout no-print">
        <aside className="settings-menu pd-card">
          {MENU.map((m) => (
            <button key={m.id} type="button" className={`settings-menu-item ${active === m.id ? "active" : ""}`} onClick={() => switchTab(m.id)}>
              <strong>{m.label}</strong>
              <span>{m.hint}</span>
            </button>
          ))}
        </aside>

        <section className="settings-content pd-card">
          {active === "profile" && (
            <form onSubmit={submitProfile} className="settings-form">
              <div className="settings-block-head">
                <h3>Profile</h3>
                <p>Linked to your record in the employee directory, so edits here and in Employees stay identical.</p>
              </div>

              <div className="profile-row">
                <div className="profile-photo">
                  <div className="profile-avatar">
                    {photo ? <img src={photo} alt="Profile" /> : initials(profileDraft.fullName)}
                  </div>
                  <label className="pd-btn">
                    Upload photo
                    <input type="file" accept="image/png,image/jpeg" onChange={onPhoto} hidden />
                  </label>
                  <small className="field-hint">JPG or PNG, up to 2 MB</small>
                </div>

                <div className="pd-form-grid settings-grid">
                  <Field label="Employee" required hint="Directory link">
                    <select className="pd-select" value={profileDraft.employeeId} onChange={chooseEmployee}>
                      {employees.map((e) => <option key={e.id} value={e.id}>{e.id} — {e.name}</option>)}
                    </select>
                  </Field>
                  <Field label="Full name" required>
                    <input className="pd-input" value={profileDraft.fullName} onChange={setP("fullName")} />
                  </Field>
                  <Field label="Email address" required>
                    <input type="email" className="pd-input" value={profileDraft.email} onChange={setP("email")} />
                  </Field>
                  <Field label="Job role / designation">
                    <input className="pd-input" value={profileDraft.jobRole} onChange={setP("jobRole")} />
                  </Field>
                  <Field label="Department">
                    <select className="pd-select" value={profileDraft.department} onChange={setP("department")}>
                      {departments.map((d) => <option key={d}>{d}</option>)}
                    </select>
                  </Field>
                  <Field label="Phone number">
                    <input type="tel" className="pd-input" value={profileDraft.phone} onChange={setP("phone")} />
                  </Field>
                  <Field label="Date of joining">
                    <input type="date" className="pd-input" value={profileDraft.joiningDate} onChange={setP("joiningDate")} max={todayISO()} />
                  </Field>
                  <Field label="Employment type">
                    <select className="pd-select" value={profileDraft.employmentType} onChange={setP("employmentType")}>
                      {EMPLOYMENT_TYPES.map((t) => <option key={t}>{t}</option>)}
                    </select>
                  </Field>
                </div>
              </div>

              <div className="password-card">
                <div>
                  <strong>Password</strong>
                  <span>Password changes need a backend service and are not stored in this demo.</span>
                </div>
                <button type="button" className="pd-btn" onClick={() => setShowPassword((v) => !v)}>
                  {showPassword ? "Hide" : "Change password"}
                </button>
              </div>
              {showPassword && (
                <div className="pd-form-grid settings-grid">
                  <Field label="Current password"><input type="password" className="pd-input" autoComplete="current-password" /></Field>
                  <Field label="New password"><input type="password" className="pd-input" autoComplete="new-password" minLength={8} /></Field>
                </div>
              )}

              {feedback}
              <div className="settings-actions">
                <button type="button" className="pd-btn" onClick={() => { setProfileDraft(profile); say(""); }}>Cancel</button>
                <button type="submit" className="pd-btn pd-btn-primary">Save changes</button>
              </div>
            </form>
          )}

          {active === "company" && (
            <form onSubmit={submitCompany} className="settings-form">
              <div className="settings-block-head">
                <h3>Company preferences</h3>
                <p>The company name appears in the sidebar, header and printouts. The date format is used on every page.</p>
              </div>
              <div className="pd-form-grid settings-grid">
                <Field label="Company name" required>
                  <input className="pd-input" value={companyDraft.name} onChange={(e) => { setCompanyDraft({ ...companyDraft, name: e.target.value }); say(""); }} />
                </Field>
                <Field label="Default department" hint="Pre-selected when adding an employee">
                  <select className="pd-select" value={companyDraft.defaultDepartment} onChange={(e) => { setCompanyDraft({ ...companyDraft, defaultDepartment: e.target.value }); say(""); }}>
                    {departments.map((d) => <option key={d}>{d}</option>)}
                  </select>
                </Field>
                <Field label="Date format" hint={`Preview: ${previewDate(companyDraft.dateFormat)}`}>
                  <select className="pd-select" value={companyDraft.dateFormat} onChange={(e) => { setCompanyDraft({ ...companyDraft, dateFormat: e.target.value }); say(""); }}>
                    {DATE_FORMATS.map((f) => <option key={f}>{f}</option>)}
                  </select>
                </Field>
              </div>
              {feedback}
              <div className="settings-actions">
                <button type="button" className="pd-btn" onClick={() => { setCompanyDraft(company); say(""); }}>Cancel</button>
                <button type="submit" className="pd-btn pd-btn-primary">Save changes</button>
              </div>
            </form>
          )}

          {active === "notifications" && (
            <form onSubmit={submitNotifications} className="settings-form">
              <div className="settings-block-head">
                <h3>Notifications</h3>
                <p>Choose which updates you would like to receive.</p>
              </div>
              <div className="toggle-list">
                {Object.keys(notifDraft).map((k) => (
                  <Toggle key={k} label={k} description={NOTIFICATION_HINTS[k]} checked={!!notifDraft[k]} onChange={(v) => { setNotifDraft({ ...notifDraft, [k]: v }); say(""); }} />
                ))}
              </div>
              {feedback}
              <div className="settings-actions">
                <button type="button" className="pd-btn" onClick={() => { setNotifDraft(notifications); say(""); }}>Cancel</button>
                <button type="submit" className="pd-btn pd-btn-primary">Save changes</button>
              </div>
            </form>
          )}

          {active === "account" && (
            <div className="settings-form">
              <div className="settings-block-head">
                <h3>Account &amp; appearance</h3>
                <p>Your sign-in details and how the application looks.</p>
              </div>
              <div className="pd-detail-grid">
                <div><span>Name</span><strong>{ADMIN.name}</strong></div>
                <div><span>Email</span><strong>{ADMIN.email}</strong></div>
                <div><span>Role</span><strong>{ADMIN.role}</strong></div>
              </div>
              <small className="admin-lock">Administrator details are fixed and are not affected by profile or directory edits.</small>
              <div>
                <h4 className="pd-section-title">Display density</h4>
                <div className="density-row" role="radiogroup" aria-label="Display density">
                  {[
                    ["comfortable", "Comfortable", "Roomy rows, easier to read"],
                    ["compact", "Compact", "More rows on screen, ideal for large teams"],
                  ].map(([id, label, hint]) => (
                    <button key={id} type="button" role="radio" aria-checked={density === id} className={`density-card ${density === id ? "active" : ""}`} onClick={() => setDensity && setDensity(id)}>
                      <strong>{label}</strong>
                      <span>{hint}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="pd-section-title">Appearance mode</h4>
                <div className="theme-select-row">
                  <select className="pd-select theme-select" value={theme} onChange={(e) => setTheme(e.target.value)} aria-label="Appearance mode">
                    {THEME_GROUPS.map((g) => (
                      <optgroup key={g.title} label={g.title}>
                        {g.themes.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
                      </optgroup>
                    ))}
                  </select>
                  <span className="theme-current">Current: <strong>{(THEMES.find((t) => t.id === theme) || {}).label || theme}</strong></span>
                </div>
              </div>
              <div>
                <h4 className="pd-section-title">Accent colour</h4>
                <div className="theme-chips" role="radiogroup" aria-label="Accent colour">
                  {["default", ...accentOptions].map((id) => (
                    <button
                      key={id}
                      type="button"
                      role="radio"
                      aria-checked={accent === id}
                      className={`theme-chip ${accent === id ? "active" : ""}`}
                      onClick={() => setAccent && setAccent(id)}
                    >
                      {id === "default" ? "Theme default" : id.charAt(0).toUpperCase() + id.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {active === "data" && (
            <div className="settings-form">
              <div className="settings-block-head">
                <h3>Data &amp; backup</h3>
                <p>Everything is stored in this browser. Download a backup to keep it safe or move it to another computer.</p>
              </div>
              <div className="pd-detail-grid">
                <div><span>Employees</span><strong>{counts.employees}</strong></div>
                <div><span>Leave requests</span><strong>{counts.leaves}</strong></div>
                <div><span>Attendance records</span><strong>{counts.attendance}</strong></div>
              </div>
              <div className="password-card">
                <div>
                  <strong>Download backup</strong>
                  <span>Saves employees, attendance, leave and settings as one JSON file.</span>
                </div>
                <button type="button" className="pd-btn pd-btn-primary" onClick={() => { onExportBackup(); say("Backup downloaded."); }}>Download</button>
              </div>
              <div className="password-card">
                <div>
                  <strong>Restore from backup</strong>
                  <span>Replaces the current data with a previously downloaded PeopleDesk backup.</span>
                </div>
                <button type="button" className="pd-btn" onClick={() => backupInput.current && backupInput.current.click()}>Choose file</button>
                <input ref={backupInput} type="file" accept="application/json,.json" onChange={onBackupFile} hidden />
              </div>
              <div className="password-card">
                <div>
                  <strong>Reset to sample data</strong>
                  <span>Clears your changes and loads the original demo employees and leave requests.</span>
                </div>
                <button
                  type="button"
                  className="pd-btn pd-btn-danger"
                  onClick={() => {
                    if (!window.confirm("Reset all data to the sample data? This cannot be undone.")) return;
                    onResetDemo();
                    say("Sample data restored.");
                  }}
                >
                  Reset
                </button>
              </div>
              {feedback}
            </div>
          )}

          {active === "activity" && (
            <div className="settings-form">
              <div className="settings-block-head">
                <h3>Activity log</h3>
                <p>A record of changes to employees, attendance and leave made in this browser. The latest 300 entries are kept.</p>
              </div>
              {auditLog.length === 0 ? (
                <div className="pd-note">No activity recorded yet. Add an employee, check someone in or review a leave request and it will appear here.</div>
              ) : (
                <div className="log-table-wrap">
                  <table className="pd-table">
                    <thead>
                      <tr><th>When</th><th>Action</th><th>Details</th><th>By</th></tr>
                    </thead>
                    <tbody>
                      {auditLog.slice(0, 100).map((l) => (
                        <tr key={l.id}>
                          <td className="pd-nowrap">{new Date(l.time).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</td>
                          <td><span className={`tag tag-${l.tone || "blue"}`}>{l.action}</span></td>
                          <td>{l.detail}</td>
                          <td className="log-actor">{l.actor}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <div className="settings-actions">
                <button
                  type="button"
                  className="pd-btn pd-btn-danger"
                  disabled={auditLog.length === 0}
                  onClick={() => { if (window.confirm("Clear the whole activity log?")) { onClearLog && onClearLog(); say("Activity log cleared."); } }}
                >
                  Clear log
                </button>
                <button
                  type="button"
                  className="pd-btn pd-btn-action"
                  disabled={auditLog.length === 0}
                  onClick={() => downloadCSV(`activity_log_${todayISO()}.csv`, [
                    ["Time", "Action", "Details", "By"],
                    ...auditLog.map((l) => [l.time, l.action, l.detail, l.actor]),
                  ])}
                >
                  <DownloadIcon /> Export CSV
                </button>
              </div>
              {feedback}
            </div>
          )}

          {active === "about" && (
            <div className="settings-form">
              <div className="settings-block-head">
                <h3>About &amp; support</h3>
                <p>{company.name} is an HR management workspace for employees, attendance, leave and reporting.</p>
              </div>
              <div className="about-grid">
                <div className="about-card">
                  <h4>Contact &amp; support</h4>
                  <p>Questions, feedback or a feature request? Reach the administrator:</p>
                  <p><strong>{ADMIN.name}</strong> · <a href={`mailto:${ADMIN.email}`}>{ADMIN.email}</a></p>
                </div>
                <div className="about-card">
                  <h4>Keyboard shortcuts</h4>
                  <ul>
                    <li><kbd>Ctrl</kbd> + <kbd>K</kbd> jump to employee search</li>
                    <li><kbd>Alt</kbd> + <kbd>1</kbd>–<kbd>6</kbd> open Dashboard, Employees, Attendance, Leave, Reports, Settings</li>
                    <li><kbd>Esc</kbd> close menus and search results</li>
                  </ul>
                </div>
                <div className="about-card">
                  <h4>Your data</h4>
                  <p>Everything is stored in this browser only. Use Data &amp; backup to download a copy or move it to another computer.</p>
                </div>
                <div className="about-card">
                  <h4>Reports &amp; printing</h4>
                  <p>Every page has a Print button, and tables can be exported as CSV. In the print dialog choose “Save as PDF” to share a report with clients.</p>
                </div>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function previewDate(fmt) {
  // formatDate follows the saved preference; preview the draft by formatting manually
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  switch (fmt) {
    case "DD/MM/YYYY": return `${dd}/${mm}/${d.getFullYear()}`;
    case "MM/DD/YYYY": return `${mm}/${dd}/${d.getFullYear()}`;
    case "YYYY-MM-DD": return `${d.getFullYear()}-${mm}-${dd}`;
    default: return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  }
}
