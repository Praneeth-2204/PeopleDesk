import React from 'react';

export default function StatCard({ label, value, cardClass = 'card-total' }) {
  return (
    <div className={`dashboard-card ${cardClass}`}>
      <span className="card-label">{label}</span>
      <h2>{value}</h2>
    </div>
  );
}