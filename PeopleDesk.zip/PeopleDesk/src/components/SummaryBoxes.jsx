import React from "react";

/* The same four boxes on the Employee, Attendance and Leave pages.
   Numbers always describe today's attendance register. */
export default function SummaryBoxes({ employees = [], todayRows = [] }) {
  const count = (list) => todayRows.filter((a) => list.includes(a.status)).length;
  const present = count(["Present", "Late", "Half-Day"]);
  const absent = count(["Absent"]);
  const onLeave = count(["On Leave"]);
  return (
    <div className="pd-stats pd-stats-4 no-print">
      <div className="pd-stat is-blue"><span>Total employees</span><strong>{employees.length}</strong></div>
      <div className="pd-stat is-green"><span>Present today</span><strong>{present}</strong></div>
      <div className="pd-stat is-red"><span>Absent today</span><strong>{absent}</strong></div>
      <div className="pd-stat is-violet"><span>On leave</span><strong>{onLeave}</strong></div>
    </div>
  );
}
