import React from "react";

/* Table / Cards switch used on the Employee, Attendance and Leave pages */
export default function ViewToggle({ value, onChange }) {
  return (
    <div className="pd-view-toggle no-print" role="group" aria-label="Choose view">
      <button type="button" className={value === "table" ? "active" : ""} onClick={() => onChange("table")} aria-pressed={value === "table"}>Table</button>
      <button type="button" className={value === "cards" ? "active" : ""} onClick={() => onChange("cards")} aria-pressed={value === "cards"}>Cards</button>
    </div>
  );
}

/* Remembers the chosen view for each page */
export function useStoredView(key) {
  const [view, setView] = React.useState(() => {
    try { return localStorage.getItem(key) === "cards" ? "cards" : "table"; } catch { return "table"; }
  });
  const set = (v) => {
    setView(v);
    try { localStorage.setItem(key, v); } catch { /* ignore */ }
  };
  return [view, set];
}
