/* Fixed administrator account. These details are intentionally NOT editable
   from Settings and never follow changes made to the employee directory. */
export const ADMIN = {
  name: "Praneeth",
  email: "dachepallipraneeth22@gmail.com",
  role: "Administrator",
};
