/**
 * Professional HRMS Design System
 * Central source of truth for colors, spacing, typography, and components
 */

export const COLORS = {
  // Primary
  primary: "#4f46e5",
  primaryDark: "#4338ca",
  primaryLight: "#a5b4fc",

  // Neutrals
  black: "#0f172a",
  gray900: "#0f172a",
  gray800: "#1e293b",
  gray700: "#334155",
  gray600: "#475569",
  gray500: "#64748b",
  gray400: "#94a3b8",
  gray300: "#cbd5e1",
  gray200: "#e2e8f0",
  gray100: "#f1f5f9",
  gray50: "#f8fafc",
  white: "#ffffff",

  // Status Colors
  success: "#10b981",
  warning: "#f59e0b",
  danger: "#ef4444",
  info: "#06b6d4",

  // Dark Mode
  darkBg: "#0f172a",
  darkCardBg: "#1e293b",
  darkBorder: "#334155",
  darkText: "#e2e8f0",
  darkTextSecondary: "#cbd5e1",
};

export const TYPOGRAPHY = {
  // Font Family
  fontFamily: {
    base: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif",
  },

  // Font Sizes
  fontSize: {
    xs: "12px",
    sm: "13px",
    base: "14px",
    lg: "15px",
    xl: "16px",
    "2xl": "18px",
    "3xl": "20px",
    "4xl": "24px",
    "5xl": "30px",
    "6xl": "36px",
  },

  // Font Weights
  fontWeight: {
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
  },

  // Line Heights
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
    loose: 2,
  },
};

export const SPACING = {
  0: "0px",
  1: "4px",
  2: "8px",
  3: "12px",
  4: "16px",
  5: "20px",
  6: "24px",
  8: "32px",
  10: "40px",
  12: "48px",
  16: "64px",
};

export const BORDER_RADIUS = {
  none: "0px",
  sm: "6px",
  md: "10px",
  lg: "12px",
  xl: "16px",
  full: "999px",
};

export const SHADOWS = {
  none: "none",
  sm: "0 2px 6px rgba(15, 23, 42, 0.04)",
  md: "0 4px 12px rgba(15, 23, 42, 0.08)",
  lg: "0 10px 25px rgba(15, 23, 42, 0.05)",
  xl: "0 20px 50px rgba(15, 23, 42, 0.15)",
  "2xl": "0 25px 60px rgba(15, 23, 42, 0.2)",
};

export const TRANSITIONS = {
  fast: "all 0.15s ease-in-out",
  normal: "all 0.2s ease-in-out",
  slow: "all 0.3s ease-in-out",
};

// Component Style Templates
export const COMPONENTS = {
  button: {
    primary: {
      padding: `${SPACING[3]} ${SPACING[5]}`,
      borderRadius: BORDER_RADIUS.md,
      fontSize: TYPOGRAPHY.fontSize.sm,
      fontWeight: TYPOGRAPHY.fontWeight.bold,
      backgroundColor: COLORS.primary,
      color: COLORS.white,
      border: "none",
      cursor: "pointer",
      transition: TRANSITIONS.normal,
      boxShadow: SHADOWS.md,
    },
    secondary: {
      padding: `${SPACING[3]} ${SPACING[5]}`,
      borderRadius: BORDER_RADIUS.md,
      fontSize: TYPOGRAPHY.fontSize.sm,
      fontWeight: TYPOGRAPHY.fontWeight.bold,
      backgroundColor: COLORS.gray100,
      color: COLORS.gray900,
      border: `1px solid ${COLORS.gray300}`,
      cursor: "pointer",
      transition: TRANSITIONS.normal,
    },
  },

  input: {
    padding: `${SPACING[3]} ${SPACING[4]}`,
    borderRadius: BORDER_RADIUS.md,
    fontSize: TYPOGRAPHY.fontSize.base,
    border: `1.5px solid ${COLORS.gray300}`,
    backgroundColor: COLORS.white,
    color: COLORS.gray900,
    outline: "none",
    transition: TRANSITIONS.fast,
  },

  card: {
    padding: SPACING[6],
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.white,
    border: `1px solid ${COLORS.gray200}`,
    boxShadow: SHADOWS.md,
  },

  modal: {
    borderRadius: BORDER_RADIUS.xl,
    backgroundColor: COLORS.white,
    boxShadow: SHADOWS.xl,
    maxWidth: "900px",
  },

  table: {
    padding: SPACING[3],
    borderColor: COLORS.gray200,
    headerBg: COLORS.gray50,
    hoverBg: COLORS.gray50,
  },
};

// Gradient Backgrounds for KPI Cards
export const GRADIENTS = {
  blue: "linear-gradient(135deg, #4f46e5, #a5b4fc)",
  teal: "linear-gradient(135deg, #0d9488, #2dd4bf)",
  purple: "linear-gradient(135deg, #7c3aed, #a78bfa)",
  amber: "linear-gradient(135deg, #d97706, #fbbf24)",
  emerald: "linear-gradient(135deg, #10b981, #6ee7b7)",
  rose: "linear-gradient(135deg, #e11d48, #fb7185)",
};

export default {
  COLORS,
  TYPOGRAPHY,
  SPACING,
  BORDER_RADIUS,
  SHADOWS,
  TRANSITIONS,
  COMPONENTS,
  GRADIENTS,
};
