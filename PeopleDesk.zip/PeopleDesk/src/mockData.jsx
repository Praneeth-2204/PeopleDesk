export const initialEmployees = [
  { id: "EMP-001", name: "Praneeth", email: "dachepallipraneeth22@gmail.com", department: "Engineering", designation: "Lead Frontend Dev", age: 29, joined: "2023-01-15", status: "Active" },
  { id: "EMP-002", name: "Sarah Connor", email: "sarah.c@peopledesk.com", department: "Design", designation: "UI/UX Designer", age: 31, joined: "2023-02-10", status: "Active" },
  { id: "EMP-003", name: "Michael Chang", email: "michael.c@peopledesk.com", department: "Sales", designation: "Account Executive", age: 34, joined: "2023-03-05", status: "On Leave" },
  { id: "EMP-004", name: "Emily Watson", email: "emily.w@peopledesk.com", department: "Finance", designation: "Financial Analyst", age: 28, joined: "2022-11-20", status: "Active" },
  { id: "EMP-005", name: "David Miller", email: "david.m@peopledesk.com", department: "Engineering", designation: "Senior Backend Dev", age: 36, joined: "2022-05-12", status: "Inactive" },
  { id: "EMP-006", name: "Jessica Taylor", email: "jessica.t@peopledesk.com", department: "HR", designation: "HR Generalist", age: 30, joined: "2023-04-18", status: "Active" },
  { id: "EMP-007", name: "Daniel Martinez", email: "daniel.m@peopledesk.com", department: "Operations", designation: "Operations Lead", age: 38, joined: "2021-09-01", status: "Active" },
  { id: "EMP-008", name: "Sophia Anderson", email: "sophia.a@peopledesk.com", department: "Marketing", designation: "Content Strategist", age: 27, joined: "2023-06-12", status: "Active" },
  { id: "EMP-009", name: "James Wilson", email: "james.w@peopledesk.com", department: "Engineering", designation: "DevOps Engineer", age: 33, joined: "2022-08-14", status: "Active" },
  { id: "EMP-010", name: "Olivia Thomas", email: "olivia.t@peopledesk.com", department: "IT", designation: "Systems Administrator", age: 32, joined: "2022-01-20", status: "Active" },
  { id: "EMP-011", name: "Benjamin Jackson", email: "benjamin.j@peopledesk.com", department: "Sales", designation: "Sales Manager", age: 41, joined: "2020-07-15", status: "Active" },
  { id: "EMP-012", name: "Mia White", email: "mia.w@peopledesk.com", department: "Design", designation: "Visual Designer", age: 26, joined: "2023-09-01", status: "Active" },
  { id: "EMP-013", name: "Lucas Harris", email: "lucas.h@peopledesk.com", department: "Engineering", designation: "Full Stack Dev", age: 30, joined: "2022-10-10", status: "Active" },
  { id: "EMP-014", name: "Charlotte Martin", email: "charlotte.m@peopledesk.com", department: "Finance", designation: "Senior Accountant", age: 35, joined: "2021-11-05", status: "Active" },
  { id: "EMP-015", name: "Henry Thompson", email: "henry.t@peopledesk.com", department: "HR", designation: "Talent Acquisition", age: 29, joined: "2023-05-15", status: "Active" },
  { id: "EMP-016", name: "Amelia Garcia", email: "amelia.g@peopledesk.com", department: "Marketing", designation: "SEO Specialist", age: 28, joined: "2023-02-28", status: "On Leave" },
  { id: "EMP-017", name: "Ethan Robinson", email: "ethan.r@peopledesk.com", department: "IT", designation: "Network Engineer", age: 34, joined: "2021-04-12", status: "Active" },
  { id: "EMP-018", name: "Harper Clark", email: "harper.c@peopledesk.com", department: "Operations", designation: "Supply Coordinator", age: 31, joined: "2022-06-25", status: "Active" },
  { id: "EMP-019", name: "Alexander Rodriguez", email: "alexander.r@peopledesk.com", department: "Engineering", designation: "QA Engineer", age: 27, joined: "2023-08-14", status: "Active" },
  { id: "EMP-020", name: "Evelyn Lewis", email: "evelyn.l@peopledesk.com", department: "Sales", designation: "Sales Executive", age: 29, joined: "2023-03-22", status: "Active" },
  { id: "EMP-021", name: "Sebastian Lee", email: "sebastian.l@peopledesk.com", department: "Engineering", designation: "Mobile Developer", age: 32, joined: "2022-09-08", status: "Active" },
  { id: "EMP-022", name: "Abigail Walker", email: "abigail.w@peopledesk.com", department: "Design", designation: "Product Designer", age: 30, joined: "2023-01-19", status: "Active" },
  { id: "EMP-023", name: "Logan Hall", email: "logan.h@peopledesk.com", department: "Finance", designation: "Payroll Specialist", age: 33, joined: "2022-02-14", status: "Active" },
  { id: "EMP-024", name: "Emily Allen", email: "emily.a@peopledesk.com", department: "HR", designation: "HR Coordinator", age: 26, joined: "2023-07-03", status: "Active" },
  { id: "EMP-025", name: "Jackson Young", email: "jackson.y@peopledesk.com", department: "Operations", designation: "Logistics Specialist", age: 35, joined: "2021-12-01", status: "Inactive" },
  { id: "EMP-026", name: "Elizabeth Hernandez", email: "elizabeth.h@peopledesk.com", department: "Marketing", designation: "Brand Manager", age: 37, joined: "2020-09-15", status: "Active" },
  { id: "EMP-027", name: "Aiden King", email: "aiden.k@peopledesk.com", department: "IT", designation: "Security Specialist", age: 33, joined: "2022-03-30", status: "Active" },
  { id: "EMP-028", name: "Aria Wright", email: "aria.w@peopledesk.com", department: "Engineering", designation: "Data Engineer", age: 28, joined: "2023-04-10", status: "Active" },
  { id: "EMP-029", name: "Matthew Lopez", email: "matthew.l@peopledesk.com", department: "Sales", designation: "Business Analyst", age: 31, joined: "2022-07-19", status: "Active" },
  { id: "EMP-030", name: "Chloe Hill", email: "chloe.h@peopledesk.com", department: "Design", designation: "Motion Designer", age: 27, joined: "2023-05-20", status: "Active" },
  { id: "EMP-031", name: "Samuel Scott", email: "samuel.s@peopledesk.com", department: "Engineering", designation: "Cloud Architect", age: 39, joined: "2020-11-01", status: "Active" },
  { id: "EMP-032", name: "Grace Green", email: "grace.g@peopledesk.com", department: "Finance", designation: "Tax Consultant", age: 34, joined: "2021-08-16", status: "On Leave" },
  { id: "EMP-033", name: "David Adams", email: "david.a@peopledesk.com", department: "IT", designation: "Helpdesk Support", age: 25, joined: "2023-10-01", status: "Active" },
  { id: "EMP-034", name: "Zoey Baker", email: "zoey.b@peopledesk.com", department: "Marketing", designation: "Social Media Lead", age: 26, joined: "2023-06-22", status: "Active" },
  { id: "EMP-035", name: "Carter Gonzalez", email: "carter.g@peopledesk.com", department: "Operations", designation: "Procurement Officer", age: 36, joined: "2021-05-18", status: "Active" },
  { id: "EMP-036", name: "Penelope Nelson", email: "penelope.n@peopledesk.com", department: "HR", designation: "People Partner", age: 32, joined: "2022-04-05", status: "Active" },
  { id: "EMP-037", name: "Luke Carter", email: "luke.c@peopledesk.com", department: "Engineering", designation: "Embedded Dev", age: 30, joined: "2022-12-12", status: "Active" },
  { id: "EMP-038", name: "Riley Mitchell", email: "riley.m@peopledesk.com", department: "Sales", designation: "Account Manager", age: 29, joined: "2023-02-15", status: "Active" },
  { id: "EMP-039", name: "Jayden Perez", email: "jayden.p@peopledesk.com", department: "Engineering", designation: "Site Reliability Eng", age: 35, joined: "2021-10-24", status: "Active" },
  { id: "EMP-040", name: "Nora Roberts", email: "nora.r@peopledesk.com", department: "Design", designation: "UX Researcher", age: 28, joined: "2023-03-14", status: "Active" },
  { id: "EMP-041", name: "Gabriel Turner", email: "gabriel.t@peopledesk.com", department: "Finance", designation: "Compliance Officer", age: 37, joined: "2020-06-11", status: "Active" },
  { id: "EMP-042", name: "Hannah Phillips", email: "hannah.p@peopledesk.com", department: "Marketing", designation: "PR Manager", age: 33, joined: "2022-01-17", status: "Active" },
  { id: "EMP-043", name: "Anthony Campbell", email: "anthony.c@peopledesk.com", department: "IT", designation: "Database Admin", age: 38, joined: "2021-03-29", status: "Active" },
  { id: "EMP-044", name: "Lily Parker", email: "lily.p@peopledesk.com", department: "Operations", designation: "Facilities Manager", age: 40, joined: "2019-12-05", status: "Active" },
  { id: "EMP-045", name: "Dylan Evans", email: "dylan.e@peopledesk.com", department: "Engineering", designation: "Security Engineer", age: 31, joined: "2022-11-14", status: "Active" },
  { id: "EMP-046", name: "Lillian Edwards", email: "lillian.e@peopledesk.com", department: "Sales", designation: "Inbound Rep", age: 25, joined: "2023-08-20", status: "Active" },
  { id: "EMP-047", name: "Isaac Collins", email: "isaac.c@peopledesk.com", department: "HR", designation: "Compensation Lead", age: 36, joined: "2021-07-22", status: "Active" },
  { id: "EMP-048", name: "Stella Stewart", email: "stella.s@peopledesk.com", department: "Engineering", designation: "AI Engineer", age: 29, joined: "2023-04-01", status: "Active" },
  { id: "EMP-049", name: "Nathan Sanchez", email: "nathan.s@peopledesk.com", department: "Design", designation: "Design System Lead", age: 34, joined: "2022-05-18", status: "Active" },
  { id: "EMP-050", name: "Victoria Morris", email: "victoria.m@peopledesk.com", department: "Finance", designation: "Internal Auditor", age: 35, joined: "2021-09-09", status: "Active" }
];

export const initialAttendance = initialEmployees.map((emp, index) => {
  if (emp.status === "On Leave" || index === 2 || index === 15 || index === 31) {
    return {
      id: emp.id,
      empId: emp.id,
      name: emp.name,
      empName: emp.name,
      department: emp.department,
      checkIn: "--",
      checkOut: "--",
      status: "On Leave"
    };
  }

  if (emp.status === "Inactive" || index === 4 || index === 24 || index === 44) {
    return {
      id: emp.id,
      empId: emp.id,
      name: emp.name,
      empName: emp.name,
      department: emp.department,
      checkIn: "--",
      checkOut: "--",
      status: "Absent"
    };
  }

  const checkInHour = 8 + (index % 2);
  const checkInMin = String((index * 7) % 60).padStart(2, "0");
  const checkOutHour = 4 + (index % 3);
  const checkOutMin = String((index * 11) % 60).padStart(2, "0");

  return {
    id: emp.id,
    empId: emp.id,
    name: emp.name,
    empName: emp.name,
    department: emp.department,
    checkIn: `0${checkInHour}:${checkInMin} AM`,
    checkOut: index % 5 === 0 ? "--" : `0${checkOutHour}:${checkOutMin} PM`,
    status: "Present"
  };
});

export const initialLeaveData = [
  { leaveId: "LV-101", id: "EMP-003", type: "Sick Leave", from: "2026-10-18", to: "2026-10-20", reason: "Viral Infection & Recovery", status: "Approved" },
  { leaveId: "LV-102", id: "EMP-016", type: "Casual Leave", from: "2026-10-21", to: "2026-10-23", reason: "Family Function", status: "Approved" },
  { leaveId: "LV-103", id: "EMP-032", type: "Paid Leave", from: "2026-10-20", to: "2026-10-25", reason: "Annual Vacation", status: "Approved" },
  { leaveId: "LV-104", id: "EMP-001", type: "Casual Leave", from: "2026-10-28", to: "2026-10-29", reason: "Personal Relocation", status: "Pending" },
  { leaveId: "LV-105", id: "EMP-007", type: "Sick Leave", from: "2026-10-24", to: "2026-10-25", reason: "Doctor Appointment", status: "Pending" },
  { leaveId: "LV-106", id: "EMP-012", type: "Paid Leave", from: "2026-11-02", to: "2026-11-06", reason: "Family Trip", status: "Pending" },
  { leaveId: "LV-107", id: "EMP-021", type: "Casual Leave", from: "2026-10-15", to: "2026-10-16", reason: "Bank Documentation", status: "Rejected" },
  { leaveId: "LV-108", id: "EMP-039", type: "Sick Leave", from: "2026-10-11", to: "2026-10-12", reason: "Migraine headache", status: "Approved" }
];