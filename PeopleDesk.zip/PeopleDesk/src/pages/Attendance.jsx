import React, { useEffect, useMemo, useState } from 'react';
import StatCard from '../components/StatCard';
import Button from '../components/Button';

// Default sample attendance records if none are supplied by the parent component
const DEFAULT_ATTENDANCE_RECORDS = [
  { empId: 'EMP-101', empName: 'Alex Morgan', department: 'Engineering', checkIn: '08:58 AM', checkOut: '05:02 PM', status: 'Present' },
  { empId: 'EMP-102', empName: 'Sarah Connor', department: 'Design', checkIn: '09:05 AM', checkOut: '--', status: 'Present' },
  { empId: 'EMP-103', empName: 'Michael Chang', department: 'Sales', checkIn: '--', checkOut: '--', status: 'On Leave' },
  { empId: 'EMP-104', empName: 'Emily Watson', department: 'Finance', checkIn: '08:45 AM', checkOut: '05:10 PM', status: 'Present' },
  { empId: 'EMP-105', empName: 'David Miller', department: 'Engineering', checkIn: '--', checkOut: '--', status: 'Absent' }
];

const getRecordId = (record) => String(record.empId ?? record.id ?? '');
const getRecordName = (record) => String(record.empName ?? record.name ?? '');

const formatTime = (date = new Date()) =>
  date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const EditIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
  </svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <line x1="10" y1="11" x2="10" y2="17" />
    <line x1="14" y1="11" x2="14" y2="17" />
  </svg>
);

export default function Attendance({
  attendanceRecords = DEFAULT_ATTENDANCE_RECORDS,
  totalEmployees,
  presentCount,
  absentCount,
  onLeaveCount,
  onAttendanceRecordsChange
}) {
  // If parent passes an empty list or nothing, fall back to DEFAULT_ATTENDANCE_RECORDS
  const [records, setRecords] = useState(
    attendanceRecords && attendanceRecords.length > 0 ? attendanceRecords : DEFAULT_ATTENDANCE_RECORDS
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [manualPunchOpen, setManualPunchOpen] = useState(false);
  const [manualPunch, setManualPunch] = useState({ empId: '', empName: '', department: 'General' });
  const [editingRecord, setEditingRecord] = useState(null);
  const [formError, setFormError] = useState('');
  const recordsPerPage = 5;

  useEffect(() => {
    if (attendanceRecords && attendanceRecords.length > 0) {
      setRecords(attendanceRecords);
    }
  }, [attendanceRecords]);

  // Derive metric card values dynamically from the records if props are omitted
  const metrics = useMemo(() => {
    return {
      total: totalEmployees ?? records.length,
      present: presentCount ?? records.filter((r) => r.status === 'Present').length,
      absent: absentCount ?? records.filter((r) => r.status === 'Absent').length,
      onLeave: onLeaveCount ?? records.filter((r) => r.status === 'On Leave').length
    };
  }, [records, totalEmployees, presentCount, absentCount, onLeaveCount]);

  const commitRecords = (nextRecords) => {
    setRecords(nextRecords);
    onAttendanceRecordsChange?.(nextRecords);
  };

  const filteredRecords = useMemo(() => records.filter((record) => {
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch = !query ||
      getRecordName(record).toLowerCase().includes(query) ||
      getRecordId(record).toLowerCase().includes(query) ||
      String(record.department ?? '').toLowerCase().includes(query);
    const matchesStatus = statusFilter === 'All' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  }), [records, searchQuery, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / recordsPerPage));
  const safePage = Math.min(currentPage, totalPages);
  const currentRecords = filteredRecords.slice((safePage - 1) * recordsPerPage, safePage * recordsPerPage);

  const saveManualPunch = (event) => {
    event.preventDefault();
    const empId = manualPunch.empId.trim().toUpperCase();
    const empName = manualPunch.empName.trim();
    if (!empId || !empName) {
      setFormError('Enter both an employee ID and name.');
      return;
    }

    const existing = records.find((record) => getRecordId(record).toLowerCase() === empId.toLowerCase());
    const time = formatTime();
    let nextRecords;

    if (existing) {
      const key = getRecordId(existing);
      if (existing.checkIn === '--' || !existing.checkIn) {
        nextRecords = records.map((record) => getRecordId(record) === key
          ? { ...record, empName, name: record.name === undefined ? undefined : empName, checkIn: time, status: 'Present' }
          : record);
      } else if (existing.checkOut === '--' || !existing.checkOut) {
        nextRecords = records.map((record) => getRecordId(record) === key
          ? { ...record, empName, name: record.name === undefined ? undefined : empName, checkOut: time }
          : record);
      } else {
        setFormError('This employee already has both a check-in and check-out recorded.');
        return;
      }
    } else {
      nextRecords = [
        ...records,
        {
          empId,
          empName,
          department: manualPunch.department || 'General',
          checkIn: time,
          checkOut: '--',
          status: 'Present'
        }
      ];
    }

    commitRecords(nextRecords);
    setManualPunchOpen(false);
    setManualPunch({ empId: '', empName: '', department: 'General' });
    setFormError('');
  };

  const saveEdit = (event) => {
    event.preventDefault();
    if (!editingRecord) return;
    const empId = editingRecord.empId.trim().toUpperCase();
    const empName = editingRecord.empName.trim();
    if (!empId || !empName) {
      setFormError('Employee ID and name are required.');
      return;
    }
    const oldId = editingRecord.originalId;
    if (records.some((record) => getRecordId(record).toLowerCase() === empId.toLowerCase() && getRecordId(record) !== oldId)) {
      setFormError('That employee ID is already used by another record.');
      return;
    }
    const nextRecords = records.map((record) => getRecordId(record) === oldId
      ? {
          ...record,
          empId,
          id: record.id === undefined ? undefined : empId,
          empName,
          name: record.name === undefined ? undefined : empName,
          department: editingRecord.department,
          checkIn: editingRecord.checkIn,
          checkOut: editingRecord.checkOut,
          status: editingRecord.status
        }
      : record);
    commitRecords(nextRecords);
    setEditingRecord(null);
    setFormError('');
  };

  const deleteRecord = (record) => {
    if (!window.confirm(`Delete attendance record for ${getRecordName(record)} (${getRecordId(record)})?`)) return;
    commitRecords(records.filter((item) => item !== record));
    setCurrentPage((page) => Math.min(page, Math.max(1, Math.ceil((filteredRecords.length - 1) / recordsPerPage))));
  };

  const startEdit = (record) => {
    setFormError('');
    setEditingRecord({
      originalId: getRecordId(record),
      empId: getRecordId(record),
      empName: getRecordName(record),
      department: record.department ?? '',
      checkIn: record.checkIn ?? '--',
      checkOut: record.checkOut ?? '--',
      status: record.status ?? 'Absent'
    });
  };

  const openManualPunch = () => {
    setFormError('');
    setManualPunch({ empId: '', empName: '', department: 'General' });
    setManualPunchOpen(true);
  };

  const whiteInputStyle = {
    backgroundColor: '#ffffff',
    color: '#0f172a',
    border: '1px solid #cbd5e1',
    borderRadius: '6px',
    padding: '9px 12px',
    fontSize: '13.5px',
    outline: 'none',
    width: '100%',
    boxSizing: 'border-box'
  };

  return (
    <div className="attendance-page" style={{ padding: '24px' }}>
      <div className="sub-header-row"><span className="breadcrumb-text"><strong>Attendance</strong></span></div>
      <h2 className="section-main-heading" style={{ fontSize: '24px', fontWeight: 800, color: '#0f172a', margin: '8px 0 4px 0' }}>Attendance Management</h2>
      <p className="section-sub-heading" style={{ fontSize: '14px', color: '#64748b', margin: '0 0 20px 0' }}>Track daily check-in, check-out, and attendance status.</p>

      {/* Metric Cards */}
      <div className="dashboard-metrics-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '25px' }}>
        <StatCard label="Total Employees" value={metrics.total} cardClass="card-total" />
        <StatCard label="Present Today" value={metrics.present} cardClass="card-present" />
        <StatCard label="Absent Today" value={metrics.absent} cardClass="card-absent" />
        <StatCard label="On Leave" value={metrics.onLeave} cardClass="card-leave" />
      </div>

      {/* Control Bar */}
      <div className="attendance-controls" style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap' }}>
        <input
          className="attendance-search"
          type="search"
          value={searchQuery}
          onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
          placeholder="Search by name, ID, or department"
          aria-label="Search attendance records"
          style={{ ...whiteInputStyle, width: '320px' }}
        />
        <select
          className="attendance-filter"
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
          aria-label="Filter by attendance status"
          style={{ ...whiteInputStyle, width: '150px', cursor: 'pointer' }}
        >
          <option value="All">All statuses</option>
          <option value="Present">Present</option>
          <option value="Absent">Absent</option>
          <option value="On Leave">On Leave</option>
        </select>
        <Button
          type="button"
          onClick={openManualPunch}
          style={{
            backgroundColor: '#4f46e5',
            color: '#ffffff',
            border: 'none',
            borderRadius: '6px',
            padding: '9px 18px',
            fontWeight: 600,
            cursor: 'pointer'
          }}
        >
          + Manual Punch
        </Button>
      </div>

      {/* Attendance Table */}
      <div className="attendance-table-wrap table-container-box" style={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '10px', overflowX: 'auto' }}>
        <table className="attendance-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '14px' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #e2e8f0', backgroundColor: '#fafbfc' }}>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Employee ID</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Employee Name</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Department</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Check In</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Check Out</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600 }}>Status</th>
              <th style={{ padding: '16px 20px', color: '#475569', fontWeight: 600, textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords.length === 0 ? (
              <tr>
                <td colSpan="7" style={{ padding: '32px', textAlign: 'center', color: '#94a3b8' }}>
                  No attendance records found.
                </td>
              </tr>
            ) : (
              currentRecords.map((record, index) => (
                <tr key={`${getRecordId(record)}-${index}`} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '16px 20px' }}><strong>{getRecordId(record)}</strong></td>
                  <td style={{ padding: '16px 20px', color: '#1e293b', fontWeight: 600 }}>{getRecordName(record)}</td>
                  <td style={{ padding: '16px 20px', color: '#334155' }}>{record.department ?? '—'}</td>
                  <td style={{ padding: '16px 20px', color: '#334155' }}>{record.checkIn ?? '--'}</td>
                  <td style={{ padding: '16px 20px', color: '#334155' }}>{record.checkOut ?? '--'}</td>
                  <td style={{ padding: '16px 20px' }}>
                    <span style={{
                      padding: '5px 12px',
                      borderRadius: '9999px',
                      fontSize: '12px',
                      fontWeight: 700,
                      backgroundColor: record.status === 'Present' ? '#dcfce7' : record.status === 'On Leave' ? '#fef3c7' : '#fee2e2',
                      color: record.status === 'Present' ? '#15803d' : record.status === 'On Leave' ? '#b45309' : '#b91c1c'
                    }}>
                      {record.status}
                    </span>
                  </td>
                  <td style={{ padding: '16px 20px', textAlign: 'right' }}>
                    <button
                      type="button"
                      onClick={() => startEdit(record)}
                      style={{
                        backgroundColor: '#eef2ff',
                        border: '1px solid #bfdbfe',
                        color: '#4338ca',
                        padding: '6px 12px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        marginRight: '8px',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px'
                      }}
                    >
                      <EditIcon />
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteRecord(record)}
                      style={{
                        backgroundColor: '#fef2f2',
                        border: '1px solid #fecaca',
                        color: '#b91c1c',
                        padding: '6px 12px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px'
                      }}
                    >
                      <TrashIcon />
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="attendance-pagination" style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '12px', marginTop: '16px' }}>
        <button
          className="page-btn-arrow"
          type="button"
          onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
          disabled={safePage === 1}
          style={{ padding: '6px 12px', backgroundColor: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', cursor: safePage === 1 ? 'not-allowed' : 'pointer' }}
        >
          Previous
        </button>
        <span style={{ fontSize: '13.5px', color: '#475569' }}>Page {safePage} of {totalPages}</span>
        <button
          className="page-btn-arrow"
          type="button"
          onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
          disabled={safePage === totalPages}
          style={{ padding: '6px 12px', backgroundColor: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '6px', cursor: safePage === totalPages ? 'not-allowed' : 'pointer' }}
        >
          Next
        </button>
      </div>

      {/* Modal Dialog for Punch & Edit */}
      {(manualPunchOpen || editingRecord) && (
        <div role="presentation" className="attendance-modal-backdrop modal-backdrop" style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '16px' }}>
          <form
            className="modal-content-box attendance-modal-card"
            onSubmit={manualPunchOpen ? saveManualPunch : saveEdit}
            role="dialog"
            aria-modal="true"
            aria-labelledby="attendance-dialog-title"
            style={{ backgroundColor: '#ffffff', padding: '28px', borderRadius: '12px', width: '100%', maxWidth: '460px', display: 'flex', flexDirection: 'column', gap: '14px', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
          >
            <h3 id="attendance-dialog-title" style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: '#0f172a', textAlign: manualPunchOpen ? 'center' : 'left' }}>
              {manualPunchOpen ? 'Manual Attendance Punch' : 'Edit Attendance Record'}
            </h3>

            <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
              Employee ID
              <input
                required
                value={manualPunchOpen ? manualPunch.empId : editingRecord.empId}
                onChange={(e) => {
                  const val = e.target.value;
                  if (manualPunchOpen) {
                    const matched = records.find((r) => getRecordId(r).toLowerCase() === val.trim().toLowerCase());
                    setManualPunch({
                      ...manualPunch,
                      empId: val,
                      empName: matched ? getRecordName(matched) : manualPunch.empName
                    });
                  } else {
                    setEditingRecord({ ...editingRecord, empId: val });
                  }
                }}
                style={whiteInputStyle}
              />
            </label>

            <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
              Employee Name
              <input
                required
                value={manualPunchOpen ? manualPunch.empName : editingRecord.empName}
                onChange={(e) => manualPunchOpen ? setManualPunch({ ...manualPunch, empName: e.target.value }) : setEditingRecord({ ...editingRecord, empName: e.target.value })}
                style={whiteInputStyle}
              />
            </label>

            {manualPunchOpen ? (
              <p className="form-helper-text" style={{ margin: 0, fontSize: '12px', color: '#475569', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', padding: '10px', borderRadius: '6px', lineHeight: '1.5' }}>
                If Check-in is missing, it logs <strong>Check-in</strong>. If Check-in exists and Check-out is missing, it logs <strong>Check-out</strong>. Brand new entries are placed at the bottom.
              </p>
            ) : (
              <>
                <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
                  Department
                  <input value={editingRecord.department} onChange={(e) => setEditingRecord({ ...editingRecord, department: e.target.value })} style={whiteInputStyle} />
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                  <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
                    Check In
                    <input value={editingRecord.checkIn} onChange={(e) => setEditingRecord({ ...editingRecord, checkIn: e.target.value })} style={whiteInputStyle} />
                  </label>
                  <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
                    Check Out
                    <input value={editingRecord.checkOut} onChange={(e) => setEditingRecord({ ...editingRecord, checkOut: e.target.value })} style={whiteInputStyle} />
                  </label>
                </div>
                <label className="input-group" style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12.5px', fontWeight: 600, color: '#334155' }}>
                  Status
                  <select value={editingRecord.status} onChange={(e) => setEditingRecord({ ...editingRecord, status: e.target.value })} style={whiteInputStyle}>
                    <option value="Present">Present</option>
                    <option value="Absent">Absent</option>
                    <option value="On Leave">On Leave</option>
                  </select>
                </label>
              </>
            )}

            {formError && <p className="modal-error-alert" role="alert" style={{ color: '#dc2626', fontSize: '12.5px', margin: 0, fontWeight: 500 }}>{formError}</p>}

            <div className="modal-btn-row" style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
              <button
                className="cancel-action-btn"
                type="button"
                onClick={() => { setManualPunchOpen(false); setEditingRecord(null); setFormError(''); }}
                style={{
                  padding: '10px 18px',
                  border: '1px solid #cbd5e1',
                  borderRadius: '6px',
                  backgroundColor: '#ffffff',
                  color: '#334155',
                  fontWeight: 600,
                  cursor: 'pointer',
                  fontSize: '13.5px'
                }}
              >
                Cancel
              </button>
              <button
                className="submit-action-btn add-theme"
                type="submit"
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#4f46e5',
                  color: '#ffffff',
                  border: 'none',
                  borderRadius: '6px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  fontSize: '13.5px'
                }}
              >
                {manualPunchOpen ? 'Record Punch' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}