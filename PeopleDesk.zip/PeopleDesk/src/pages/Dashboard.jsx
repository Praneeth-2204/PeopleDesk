import React from 'react';
import StatCard from '../components/StatCard';

export default function Dashboard({ totalEmployees, presentCount, onLeaveCount, openRolesCount }) {
  return (
    <div>
      <div className="sub-header-row">
        <span className="breadcrumb-text"><strong>Dashboard</strong></span>
      </div>

      <h2 className="section-main-heading">Dashboard Overview</h2>
      <p className="section-sub-heading">Real-time system metrics and organizational summary.</p>

      {/* 4 Cards in one full-width row */}
      <div className="dashboard-metrics-grid">
        <StatCard label="Total Employees" value={totalEmployees} cardClass="card-total" />
        <StatCard label="Present Today" value={presentCount} cardClass="card-present" />
        <StatCard label="On Leave" value={onLeaveCount} cardClass="card-leave" />
        <StatCard label="Open Roles" value={openRolesCount} cardClass="card-roles" />
      </div>

      <div className="table-container-box">
        <h3>Recent System Activity</h3>
        <p style={{ fontSize: '14px', color: '#64748b', marginTop: '10px' }}>
          All systems running normally. Active workforce database is fully synchronized.
        </p>
      </div>
    </div>
  );
}