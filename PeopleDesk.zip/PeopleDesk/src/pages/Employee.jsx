import React from "react";
import Button from "./Button";

// Built-in SVG Icons
const EditIcon = ({ size = 15, color = "currentColor" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
  </svg>
);

const DeleteIcon = ({ size = 15, color = "currentColor" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <line x1="10" y1="11" x2="10" y2="17" />
    <line x1="14" y1="11" x2="14" y2="17" />
  </svg>
);

export default function Employee({
  employees,
  filteredCount,
  currentRecords,
  searchQuery,
  setSearchQuery,
  setCurrentPage,
  totalPages,
  currentPage,
  handleEdit,
  handleDelete,
  openAddModal
}) {
  return (
    <div style={{ width: "100%" }}>
      <div className="sub-header-row">
        <span className="breadcrumb-text"><strong>Employee</strong></span>
        <Button className="btn-add-emp" onClick={openAddModal}>
          + Add Employee
        </Button>
      </div>

      <h2 className="section-main-heading">Employee</h2>
      <p className="section-sub-heading">Manage records and view employee information.</p>

      <div className="stat-box-card">
        <span className="stat-box-label">Total Employees</span>
        <h2>{employees.length}</h2>
      </div>

      <div className="table-container-box">
        <div className="table-top-bar">
          <h3>Employee Records</h3>
          <span className="record-count-text">{filteredCount} records</span>
        </div>

        <div className="search-box-wrap">
          <input
            type="text"
            className="search-input-field"
            placeholder="🔍 Search by ID, name or email..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        <div className="table-responsive-wrapper">
          <table className="light-theme-table">
            <thead>
              <tr>
                <th>EMPLOYEE ID</th>
                <th>EMPLOYEE</th>
                <th>DEPARTMENT</th>
                <th>DESIGNATION</th>
                <th>EMAIL</th>
                <th>STATUS</th>
                <th>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {currentRecords.length > 0 ? (
                currentRecords.map((emp) => (
                  <tr key={emp.id}>
                    <td>
                      <span
                        className="table-clickable-id"
                        onClick={() => handleEdit(emp)}
                        title="Click to update"
                      >
                        {emp.id}
                      </span>
                    </td>
                    <td>
                      <strong>{emp.name}</strong>
                      <span className="emp-age-sub">Age: {emp.age}</span>
                    </td>
                    <td>{emp.department}</td>
                    <td>{emp.designation}</td>
                    <td>{emp.email}</td>
                    <td>
                      <span className={`status-pill-${emp.status.toLowerCase().replace(" ", "-")}`}>
                        {emp.status}
                      </span>
                    </td>
                    <td>
                      <Button
                        onClick={() => handleEdit(emp)}
                        className="action-btn edit-action"
                        title="Edit employee"
                      >
                        <EditIcon size={14} />
                        <span>Edit</span>
                      </Button>
                      <Button
                        onClick={() => handleDelete(emp.id)}
                        className="action-btn delete-action"
                        title="Delete employee"
                      >
                        <DeleteIcon size={14} />
                        <span>Delete</span>
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" style={{ textAlign: "center", padding: "20px", color: "#64748b" }}>
                    No employees found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="pagination-row">
          <Button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="page-btn-arrow"
          >
            &lt;
          </Button>
          <span className="page-indicator-text">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="page-btn-arrow"
          >
            &gt;
          </Button>
        </div>
      </div>
    </div>
  );
}