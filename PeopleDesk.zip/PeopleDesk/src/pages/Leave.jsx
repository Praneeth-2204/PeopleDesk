import React, { useState } from 'react';
import StatCard from '../components/StatCard';
import Button from '../components/Button';

const defaultEmployees = [
  { id: "EMP-001", name: "Alex Morgan", email: "alex.m@peopledesk.com", department: "Engineering", role: "Frontend Dev", joined: "2024-03-15", status: "Active" },
  { id: "EMP-002", name: "Sarah Connor", email: "sarah.c@peopledesk.com", department: "Design", role: "UI/UX Designer", joined: "2023-08-01", status: "Active" },
  { id: "EMP-003", name: "Michael Chang", email: "michael.c@peopledesk.com", department: "Sales", role: "Account Exec", joined: "2024-01-10", status: "On Leave" },
  { id: "EMP-004", name: "Emily Watson", email: "emily.w@peopledesk.com", department: "Finance", role: "Financial Analyst", joined: "2022-11-20", status: "Active" },
  { id: "EMP-005", name: "David Miller", email: "david.m@peopledesk.com", department: "Engineering", role: "Backend Dev", joined: "2023-05-12", status: "Inactive" }
];

export default function Leave({ employees = defaultEmployees }) {
  const [leaveRequests, setLeaveRequests] = useState([
    {
      id: 'LV001',
      empId: 'EMP-004',
      empName: 'Emily Watson',
      leaveType: 'Casual Leave',
      startDate: '2026-10-14',
      endDate: '2026-10-16',
      days: 3,
      reason: 'Personal family event',
      status: 'Approved'
    },
    {
      id: 'LV002',
      empId: 'EMP-003',
      empName: 'Michael Chang',
      leaveType: 'Sick Leave',
      startDate: '2026-10-14',
      endDate: '2026-10-15',
      days: 2,
      reason: 'Fever and rest',
      status: 'Pending'
    },
    {
      id: 'LV003',
      empId: 'EMP-001',
      empName: 'Alex Morgan',
      leaveType: 'Vacation Leave',
      startDate: '2026-10-20',
      endDate: '2026-10-25',
      days: 6,
      reason: 'Annual trip',
      status: 'Pending'
    },
    {
      id: 'LV004',
      empId: 'EMP-002',
      empName: 'Sarah Connor',
      leaveType: 'Maternity/Paternity',
      startDate: '2026-10-01',
      endDate: '2026-11-01',
      days: 32,
      reason: 'Maternity leave',
      status: 'Approved'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [showApplyModal, setShowApplyModal] = useState(false);

  const [leaveForm, setLeaveForm] = useState({
    empId: employees[0]?.id || '',
    leaveType: 'Casual Leave',
    startDate: '',
    endDate: '',
    reason: ''
  });

  const recordsPerPage = 5;

  const handleStatusChange = (id, newStatus) => {
    setLeaveRequests((prev) =>
      prev.map((req) => (req.id === id ? { ...req, status: newStatus } : req))
    );
  };

  const handleApplySubmit = (e) => {
    e.preventDefault();
    if (!leaveForm.empId || !leaveForm.startDate || !leaveForm.endDate) return;

    const selectedEmp = employees.find((e) => e.id === leaveForm.empId);
    const start = new Date(leaveForm.startDate);
    const end = new Date(leaveForm.endDate);
    const calculatedDays = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1);

    const newRequest = {
      id: `LV${String(leaveRequests.length + 1).padStart(3, '0')}`,
      empId: leaveForm.empId,
      empName: selectedEmp ? selectedEmp.name : 'Unknown Employee',
      leaveType: leaveForm.leaveType,
      startDate: leaveForm.startDate,
      endDate: leaveForm.endDate,
      days: calculatedDays,
      reason: leaveForm.reason || 'Not specified',
      status: 'Pending'
    };

    setLeaveRequests([newRequest, ...leaveRequests]);
    setShowApplyModal(false);
    setLeaveForm({
      empId: employees[0]?.id || '',
      leaveType: 'Casual Leave',
      startDate: '',
      endDate: '',
      reason: ''
    });
  };

  const filteredRequests = leaveRequests.filter((req) => {
    const matchesSearch =
      req.empName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.empId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.leaveType.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || req.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.ceil(filteredRequests.length / recordsPerPage) || 1;
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredRequests.slice(indexOfFirstRecord, indexOfLastRecord);

  const pendingCount = leaveRequests.filter((r) => r.status === 'Pending').length;
  const approvedCount = leaveRequests.filter((r) => r.status === 'Approved').length;
  const rejectedCount = leaveRequests.filter((r) => r.status === 'Rejected').length;

  return (
    <div style={{ width: '100%', maxWidth: '100%' }}>
      {/* Breadcrumb Header */}
      <div className="sub-header-row">
        <span className="breadcrumb-text"><strong>Leave</strong></span>
        <Button className="btn-add-emp" onClick={() => setShowApplyModal(true)}>
          + Apply Leave
        </Button>
      </div>

      <h2 className="section-main-heading">Leave Requests & Approvals</h2>
      <p className="section-sub-heading">Review, approve, and track employee leave applications.</p>

      {/* 4 Cards Grid */}
      <div className="dashboard-metrics-grid" style={{ marginBottom: '25px' }}>
        <StatCard label="Total Applications" value={leaveRequests.length} cardClass="card-total" />
        <StatCard label="Pending Approval" value={pendingCount} cardClass="card-roles" />
        <StatCard label="Approved Leaves" value={approvedCount} cardClass="card-present" />
        <StatCard label="Rejected Leaves" value={rejectedCount} cardClass="card-leave" />
      </div>

      {/* Main Table Card */}
      <div
        className="table-container-box"
        style={{
          width: '100%',
          boxSizing: 'border-box',
          overflow: 'hidden',
          backgroundColor: '#ffffff',
          borderRadius: '12px',
          padding: '24px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
          border: '1px solid #e2e8f0'
        }}
      >
        <div className="table-top-bar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: '700', color: '#0f172a', margin: 0 }}>Leave Applications</h3>
          <span className="record-count-text">{filteredRequests.length} records</span>
        </div>

        {/* Search & Filter Bar */}
        <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', width: '100%' }}>
          <input
            type="text"
            className="search-input-field"
            placeholder="🔍 Search by employee name, ID or leave type..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            style={{
              flex: 1,
              padding: '10px 16px',
              borderRadius: '8px',
              border: '1px solid #cbd5e1',
              fontSize: '14px'
            }}
          />
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            style={{
              padding: '10px 14px',
              borderRadius: '8px',
              border: '1px solid #cbd5e1',
              backgroundColor: '#fff',
              fontSize: '14px',
              color: '#334155',
              cursor: 'pointer'
            }}
          >
            <option value="All">All Requests</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        {/* Responsive Contained Table */}
        <div style={{ width: '100%', overflowX: 'auto' }}>
          <table
            className="light-theme-table"
            style={{
              width: '100%',
              minWidth: '780px',
              tableLayout: 'fixed',
              borderCollapse: 'collapse'
            }}
          >
            <thead>
              <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                <th style={{ width: '11%', padding: '12px 10px', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>REQ ID</th>
                <th style={{ width: '18%', padding: '12px 10px', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>EMPLOYEE</th>
                <th style={{ width: '15%', padding: '12px 10px', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>LEAVE TYPE</th>
                <th style={{ width: '16%', padding: '12px 10px', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>DURATION</th>
                <th style={{ width: '9%', padding: '12px 10px', textAlign: 'center', fontSize: '12px', color: '#64748b' }}>DAYS</th>
                <th style={{ width: '16%', padding: '12px 10px', textAlign: 'left', fontSize: '12px', color: '#64748b' }}>REASON</th>
                <th style={{ width: '10%', padding: '12px 10px', textAlign: 'center', fontSize: '12px', color: '#64748b' }}>STATUS</th>
                <th style={{ width: '15%', padding: '12px 10px', textAlign: 'center', fontSize: '12px', color: '#64748b' }}>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {currentRecords.length > 0 ? (
                currentRecords.map((req) => (
                  <tr key={req.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '14px 10px' }}><strong>{req.id}</strong></td>
                    <td style={{ padding: '14px 10px' }}>
                      <strong style={{ display: 'block', color: '#0f172a' }}>{req.empName}</strong>
                      <span style={{ fontSize: '12px', color: '#94a3b8' }}>{req.empId}</span>
                    </td>
                    <td style={{ padding: '14px 10px' }}>{req.leaveType}</td>
                    <td style={{ padding: '14px 10px', whiteSpace: 'nowrap', fontSize: '13px' }}>
                      {req.startDate} <br />
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>to {req.endDate}</span>
                    </td>
                    <td style={{ padding: '14px 10px', textAlign: 'center' }}>
                      {req.days} {req.days === 1 ? 'day' : 'days'}
                    </td>
                    <td
                      style={{
                        padding: '14px 10px',
                        maxWidth: '140px',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis'
                      }}
                      title={req.reason}
                    >
                      {req.reason}
                    </td>
                    <td style={{ padding: '14px 10px', textAlign: 'center' }}>
                      <span
                        className={
                          req.status === 'Approved'
                            ? 'status-pill-active'
                            : req.status === 'Rejected'
                            ? 'status-pill-inactive'
                            : 'status-pill-on-leave'
                        }
                      >
                        {req.status}
                      </span>
                    </td>
                    <td style={{ padding: '14px 10px', textAlign: 'center' }}>
                      {req.status === 'Pending' ? (
                        <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                          <Button
                            onClick={() => handleStatusChange(req.id, 'Approved')}
                            className="action-btn edit-action"
                            style={{ backgroundColor: '#22c55e', color: '#fff', padding: '4px 8px', fontSize: '12px' }}
                          >
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleStatusChange(req.id, 'Rejected')}
                            className="action-btn delete-action"
                            style={{ padding: '4px 8px', fontSize: '12px' }}
                          >
                            Reject
                          </Button>
                        </div>
                      ) : (
                        <span style={{ fontSize: '12px', color: '#94a3b8' }}>Processed</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '24px', color: '#64748b' }}>
                    No leave requests found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="pagination-row" style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '10px', marginTop: '16px' }}>
          <Button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="page-btn-arrow"
          >
            &lt;
          </Button>
          <span className="page-indicator-text">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="page-btn-arrow"
          >
            &gt;
          </Button>
        </div>
      </div>

      {/* Apply Leave Modal */}
      {showApplyModal && (
        <div className="modal-backdrop">
          <div className="modal-content-box">
            <h3>Apply for Leave</h3>
            <form onSubmit={handleApplySubmit}>
              <div className="input-group">
                <label>Select Employee</label>
                <select
                  value={leaveForm.empId}
                  onChange={(e) => setLeaveForm({ ...leaveForm, empId: e.target.value })}
                  required
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.id} - {emp.name} ({emp.department})
                    </option>
                  ))}
                </select>
              </div>

              <div className="input-group">
                <label>Leave Type</label>
                <select
                  value={leaveForm.leaveType}
                  onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value })}
                >
                  <option value="Casual Leave">Casual Leave</option>
                  <option value="Sick Leave">Sick Leave</option>
                  <option value="Vacation Leave">Vacation Leave</option>
                  <option value="Maternity/Paternity">Maternity/Paternity</option>
                </select>
              </div>

              <div className="input-row-2">
                <div className="input-group">
                  <label>Start Date</label>
                  <input
                    type="date"
                    value={leaveForm.startDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>End Date</label>
                  <input
                    type="date"
                    value={leaveForm.endDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="input-group">
                <label>Reason</label>
                <input
                  type="text"
                  placeholder="e.g. Vacation, recovery, emergency"
                  value={leaveForm.reason}
                  onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                  required
                />
              </div>

              <div className="modal-btn-row">
                <Button type="submit" className="submit-action-btn add-theme">
                  Submit Request
                </Button>
                <Button type="button" className="cancel-action-btn" onClick={() => setShowApplyModal(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}