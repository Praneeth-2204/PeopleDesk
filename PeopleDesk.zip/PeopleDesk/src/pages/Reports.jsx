import React from 'react';
import StatCard from '../components/StatCard';

export default function Reports({
  employees = [],
  attendanceRecords = [],
  leaveRequests = []
}) {
  const totalEmployees = employees.length;
  const activeCount = employees.filter((e) => e.status === 'Active').length;
  const presentCount = attendanceRecords.filter((a) => a.status === 'Present').length;
  const pendingLeaves = leaveRequests.filter((l) => l.status === 'Pending').length;

  const departmentColors = {
    IT: '#6366f1',
    HR: '#ec4899',
    Finance: '#10b981',
    Marketing: '#f59e0b',
    Sales: '#8b5cf6',
    Engineering: '#06b6d4',
    Operations: '#64748b'
  };

  const departmentCounts = employees.reduce((acc, emp) => {
    acc[emp.department] = (acc[emp.department] || 0) + 1;
    return acc;
  }, {});

  const absentCount = attendanceRecords.filter((a) => a.status === 'Absent').length;
  const onLeaveCount = attendanceRecords.filter((a) => a.status === 'On Leave').length || 
                       employees.filter((e) => e.status === 'On Leave').length;

  const attendanceData = [
    { label: 'Present', count: presentCount, color: '#10b981' },
    { label: 'On Leave', count: onLeaveCount, color: '#f59e0b' },
    { label: 'Absent', count: absentCount, color: '#ef4444' }
  ];

  const maxAttendance = Math.max(...attendanceData.map((d) => d.count), 1);

  return (
    <div style={{ width: '100%' }}>
      <div className="sub-header-row">
        <span className="breadcrumb-text"><strong>Reports</strong></span>
      </div>

      <h2 className="section-main-heading">Reports & Analytics</h2>
      <p className="section-sub-heading">HR Overview & Employee insights</p>

      <div className="dashboard-metrics-grid" style={{ marginBottom: '28px' }}>
        <StatCard label="Total Employees" value={totalEmployees} cardClass="card-total" />
        <StatCard label="Active" value={activeCount} cardClass="card-present" />
        <StatCard label="Present" value={presentCount} cardClass="card-present" />
        <StatCard label="Pending Leaves" value={pendingLeaves} cardClass="card-roles" />
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))',
          gap: '24px',
          width: '100%'
        }}
      >
        <div className="table-container-box">
          <div className="table-top-bar">
            <h3>Employee Department</h3>
            <span className="record-count-text">{Object.keys(departmentCounts).length} Depts</span>
          </div>
          <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '20px' }}>
            Headcount distribution across company units
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {Object.entries(departmentCounts).map(([dept, count]) => {
              const color = departmentColors[dept] || '#6366f1';
              const percentage = totalEmployees > 0 ? Math.round((count / totalEmployees) * 100) : 0;

              return (
                <div key={dept}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span
                        style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '50%',
                          backgroundColor: color,
                          display: 'inline-block'
                        }}
                      />
                      <strong>{dept}</strong>
                    </span>
                    <span style={{ color: '#64748b' }}>
                      {count} ({percentage}%)
                    </span>
                  </div>
                  <div
                    style={{
                      width: '100%',
                      height: '8px',
                      backgroundColor: '#f1f5f9',
                      borderRadius: '4px',
                      overflow: 'hidden'
                    }}
                  >
                    <div
                      style={{
                        width: `${percentage}%`,
                        height: '100%',
                        backgroundColor: color,
                        borderRadius: '4px'
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="table-container-box">
          <div className="table-top-bar">
            <h3>Attendance Summary</h3>
            <span className="record-count-text">Today</span>
          </div>
          <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '20px' }}>
            Daily check-in and absence status
          </p>

          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-around',
              height: '220px',
              borderBottom: '2px solid #e2e8f0',
              paddingBottom: '10px',
              paddingTop: '20px'
            }}
          >
            {attendanceData.map((item) => {
              const barHeight = Math.max((item.count / maxAttendance) * 160, 20);
              return (
                <div
                  key={item.label}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px'
                  }}
                >
                  <strong style={{ fontSize: '14px', color: item.color }}>{item.count}</strong>
                  <div
                    style={{
                      width: '48px',
                      height: `${barHeight}px`,
                      backgroundColor: item.color,
                      borderRadius: '6px 6px 0 0',
                      transition: 'height 0.3s ease'
                    }}
                  />
                  <span style={{ fontSize: '13px', fontWeight: '600', color: '#475569' }}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}