/* Shared helpers used by Attendance, Leave and Reports modules. */

export const todayISO = () => {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
};

/* ---------- Company-wide preferences (set from Settings, applied everywhere) ---------- */
export const DATE_FORMATS = ["DD MMM YYYY", "DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD"];
let dateFormatPref = "DD MMM YYYY";
let companyNamePref = "Employee Management System";
export const setDateFormatPref = (fmt) => { dateFormatPref = DATE_FORMATS.includes(fmt) ? fmt : "DD MMM YYYY"; };
export const setCompanyNamePref = (name) => { companyNamePref = (name || "").trim() || "Employee Management System"; };
export const getCompanyName = () => companyNamePref;

const pad2 = (n) => String(n).padStart(2, "0");
const fmtByPref = (d, longMonth) => {
  const dd = pad2(d.getDate());
  const mm = pad2(d.getMonth() + 1);
  const yyyy = d.getFullYear();
  switch (dateFormatPref) {
    case "DD/MM/YYYY": return `${dd}/${mm}/${yyyy}`;
    case "MM/DD/YYYY": return `${mm}/${dd}/${yyyy}`;
    case "YYYY-MM-DD": return `${yyyy}-${mm}-${dd}`;
    default:
      return longMonth
        ? d.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })
        : d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  }
};

/* "2026-10-24" -> "24 October 2026" (or the format chosen in Settings) */
export const formatDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return fmtByPref(d, true);
};

/* "2023-01-15" -> "15 Jan 2023" (compact, for tables) */
export const formatDateShort = (iso) => {
  if (!iso) return "—";
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return fmtByPref(d, false);
};

/* One compact cell for a leave period: "12 Oct 2026 – 14 Oct 2026" (a single day shows once) */
export const formatDateRange = (a, b) => {
  if (!a && !b) return "—";
  if (!b || a === b) return formatDateShort(a);
  if (!a) return formatDateShort(b);
  return `${formatDateShort(a)} – ${formatDateShort(b)}`;
};

/* Length of service from a joining date, e.g. "3 yrs 9 mos" */
export const tenure = (iso) => {
  if (!iso) return "—";
  const start = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(start.getTime())) return "—";
  const now = new Date();
  if (start > now) return "Joining soon";
  let months = (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth());
  if (now.getDate() < start.getDate()) months -= 1;
  months = Math.max(0, months);
  const y = Math.floor(months / 12);
  const m = months % 12;
  if (y === 0 && m === 0) return "Less than a month";
  const parts = [];
  if (y) parts.push(`${y} ${y === 1 ? "yr" : "yrs"}`);
  if (m) parts.push(`${m} ${m === 1 ? "mo" : "mos"}`);
  return parts.join(" ");
};

/* Current time as "09:02 AM" */
export const nowTime12 = () =>
  new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });

/* "09:02 AM" -> "09:02"  (for <input type="time">) */
export const to24 = (t) => {
  if (!t || t === "--" || t === "—") return "";
  const m = String(t).match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (!m) return "";
  let h = parseInt(m[1], 10);
  const min = m[2];
  const ap = m[3] && m[3].toUpperCase();
  if (ap === "PM" && h < 12) h += 12;
  if (ap === "AM" && h === 12) h = 0;
  return `${String(h).padStart(2, "0")}:${min}`;
};

/* "14:05" -> "02:05 PM" */
export const to12 = (t) => {
  if (!t) return "--";
  const m = String(t).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return t;
  let h = parseInt(m[1], 10);
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${String(h).padStart(2, "0")}:${m[2]} ${ap}`;
};

export const hasTime = (t) => !!t && t !== "--" && t !== "—";

/* Minutes since midnight for a "09:02 AM" string (or -1) */
export const minutesOf = (t) => {
  const v = to24(t);
  if (!v) return -1;
  const [h, m] = v.split(":").map(Number);
  return h * 60 + m;
};

/* Worked hours between check in / check out, e.g. "8h 12m" */
export const workedHours = (inT, outT) => {
  const a = minutesOf(inT);
  const b = minutesOf(outT);
  if (a < 0 || b < 0 || b < a) return "—";
  const diff = b - a;
  return `${Math.floor(diff / 60)}h ${String(diff % 60).padStart(2, "0")}m`;
};

/* Attendance rows from older data have no date and use "Leave" */
export const normalizeAttendance = (rec, date = todayISO(), employees = []) => {
  const empId = rec.empId || rec.id;
  const emp = employees.find((e) => e.id === empId);
  return {
  ...rec,
  empId,
  empName: emp ? emp.name : rec.empName || rec.name,
  department: emp ? emp.department : rec.department,
  date: rec.date || date,
  checkIn: rec.checkIn || "--",
  checkOut: rec.checkOut || "--",
  status: rec.status === "Leave" ? "On Leave" : rec.status,
  };
};

/* Leave rows may be { id, type, from, to } (mock data) or { empId, leaveType, startDate, endDate } */
export const normalizeLeave = (rec, employees = []) => {
  const empId = rec.empId || rec.id;
  const emp = employees.find((e) => e.id === empId) || {};
  return {
    ...rec,
    leaveId: rec.leaveId || `LV-${empId}-${rec.startDate || rec.from || ""}`,
    empId,
    empName: emp.name || rec.empName || rec.name || "",
    department: emp.department || rec.department || "",
    leaveType: rec.leaveType || rec.type || "Casual Leave",
    startDate: rec.startDate || rec.from || "",
    endDate: rec.endDate || rec.to || "",
    reason: rec.reason || "",
    status: rec.status || "Pending",
  };
};

export const daysBetween = (a, b) => {
  if (!a || !b) return 0;
  const diff = Math.abs(new Date(b) - new Date(a));
  return Math.round(diff / 86400000) + 1;
};

export const initials = (name = "") =>
  name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join("") || "?";

/* CSV download (works in every browser, escapes quotes) */
export const downloadCSV = (filename, rows) => {
  const csv = rows
    .map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(","))
    .join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 500);
};


/* ---------- Attendance defaults & syncing ---------- */

/* Is this employee covered by an approved leave today? */
const onApprovedLeaveToday = (empId, leaveData, employees, day) =>
  leaveData.some((l) => {
    const n = normalizeLeave(l, employees);
    return n.empId === empId && n.status === "Approved" && n.startDate <= day && day <= n.endDate;
  });

/* Everyone starts the day as Absent (or On Leave when they are away). */
export const defaultAttendanceFor = (emp, leaveData = [], employees = [], day = todayISO()) => ({
  id: emp.id,
  empId: emp.id,
  name: emp.name,
  empName: emp.name,
  department: emp.department,
  date: day,
  checkIn: "--",
  checkOut: "--",
  status: emp.status === "On Leave" || onApprovedLeaveToday(emp.id, leaveData, employees, day) ? "On Leave" : "Absent",
});

/* Keeps attendance in step with the employee list:
   - every employee has a record for today (default Absent)
   - records of deleted employees disappear
   - names / departments follow the employee record
   - untouched Absent / On Leave rows follow the employee's current status */
export const reconcileAttendance = (records = [], employees = [], leaveData = [], day = todayISO()) => {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const seen = new Set();
  const out = [];

  records.forEach((raw) => {
    const r = normalizeAttendance(raw, day);
    const emp = byId.get(r.empId);
    if (!emp) return;
    const key = `${r.empId}|${r.date}`;
    if (seen.has(key)) return;
    seen.add(key);

    let next = { ...raw, ...r, name: emp.name, empName: emp.name, department: emp.department };
    if (r.date === day && !r.manualLeave && !r.manualAbsent && !hasTime(r.checkIn) && (r.status === "Absent" || r.status === "On Leave")) {
      next = { ...next, status: defaultAttendanceFor(emp, leaveData, employees, day).status };
    }
    out.push(next);
  });

  employees.forEach((emp) => {
    if (!seen.has(`${emp.id}|${day}`)) out.push(defaultAttendanceFor(emp, leaveData, employees, day));
  });
  return out;
};

/* Leave requests of deleted employees are dropped */
export const reconcileLeaves = (leaves = [], employees = []) => {
  const ids = new Set(employees.map((e) => e.id));
  return leaves.filter((l) => ids.has(l.empId || l.id));
};

/* ---------- Printing ---------- */

/* Prints only the element marked .print-area (a modal, a report...) */
export const printView = () => {
  document.body.classList.add("printing-view");
  const done = () => {
    document.body.classList.remove("printing-view");
    window.removeEventListener("afterprint", done);
  };
  window.addEventListener("afterprint", done);
  window.print();
};


/* ---------- E-mail an employee's details to the administrator ---------- */
export const employeeMailLink = (emp, to) => {
  const lines = [
    `Employee details - ${getCompanyName()}`,
    "",
    `Employee ID : ${emp.id}`,
    `Name        : ${emp.name}`,
    `Email       : ${emp.email || "-"}`,
    `Department  : ${emp.department || "-"}`,
    `Designation : ${emp.designation || "-"}`,
    `Joined      : ${emp.joined ? formatDate(emp.joined) : "-"}`,
    `Service     : ${tenure(emp.joined)}`,
    `Status      : ${emp.status || "-"}`,
    "",
    `Sent from ${getCompanyName()} on ${formatDate(todayISO())}`,
  ];
  return `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(`Employee details: ${emp.name} (${emp.id})`)}&body=${encodeURIComponent(lines.join("\n"))}`;
};
